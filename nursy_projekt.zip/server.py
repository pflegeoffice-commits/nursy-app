#!/usr/bin/env python3
import os, json, uuid, hashlib, hmac, time
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename
import sqlite3

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DB_PATH    = os.path.join(BASE_DIR, 'nursy.db')
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_EXTENSIONS = {'png','jpg','jpeg','gif','webp','pdf','doc','docx','txt','heic','heif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

app = Flask(__name__, static_folder=BASE_DIR)
app.secret_key = os.environ.get('SECRET_KEY', 'nursy-dev-secret-2024')
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# When running behind Replit's HTTPS proxy, use Secure + SameSite=None so that
# session cookies are forwarded correctly even inside cross-origin iframes.
_is_https = bool(
    os.environ.get('REPLIT_DEPLOYMENT') or
    os.environ.get('REPLIT_DEV_DOMAIN') or
    os.environ.get('REPLIT_DOMAINS')
)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE']   = _is_https
app.config['SESSION_COOKIE_SAMESITE'] = 'None' if _is_https else 'Lax'


# ── DB ─────────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

ADMIN_PASSWORD = 'NursyAdmin2024!'

# ── Token Auth (fallback for environments where cookies fail) ────────────────

def _make_token(role, uid=''):
    ts   = str(int(time.time()))
    data = f"{role}|{uid}|{ts}"
    sig  = hmac.new(app.secret_key.encode(), data.encode(), 'sha256').hexdigest()
    return f"{data}|{sig}"

def _verify_token(token, max_age=86400 * 7):
    try:
        parts = token.split('|')
        if len(parts) != 4:
            return None
        role, uid, ts, sig = parts
        if time.time() - int(ts) > max_age:
            return None
        data     = f"{role}|{uid}|{ts}"
        expected = hmac.new(app.secret_key.encode(), data.encode(), 'sha256').hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        return {'role': role, 'uid': uid}
    except Exception:
        return None

def _token_from_request():
    auth = request.headers.get('X-Nursy-Token', '')
    if auth:
        return _verify_token(auth)
    return None

def init_db():
    with get_db() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS caregivers (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            gender TEXT DEFAULT '',
            address TEXT DEFAULT '',
            plz TEXT DEFAULT '',
            ort TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS patients (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT DEFAULT '',
            password_hash TEXT DEFAULT '',
            gender TEXT DEFAULT '',
            address TEXT DEFAULT '',
            plz TEXT DEFAULT '',
            ort TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            birth TEXT DEFAULT '',
            hauptgrund TEXT DEFAULT '',
            haeufigkeit TEXT DEFAULT '',
            angehoerige TEXT DEFAULT '[]',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            patient_id TEXT NOT NULL,
            patient_name TEXT NOT NULL,
            patient_gender TEXT DEFAULT '',
            patient_address TEXT DEFAULT '',
            patient_plz TEXT DEFAULT '',
            patient_ort TEXT DEFAULT '',
            patient_birth TEXT DEFAULT '',
            patient_data TEXT DEFAULT '{}',
            anamnese TEXT DEFAULT '{}',
            pflegestufe TEXT DEFAULT '',
            frequenz TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            caregiver_id TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS caregiver_status (
            caregiver_id TEXT PRIMARY KEY,
            status TEXT DEFAULT 'active',
            plan TEXT DEFAULT 'normal',
            notes TEXT DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS dienste (
            id TEXT PRIMARY KEY,
            caregiver_id TEXT NOT NULL,
            caregiver_name TEXT NOT NULL,
            datum TEXT NOT NULL,
            von TEXT NOT NULL,
            bis TEXT NOT NULL,
            typ TEXT DEFAULT 'bereitschaft',
            fahrzeug TEXT DEFAULT '',
            notiz TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS admin_messages (
            id TEXT PRIMARY KEY,
            text TEXT NOT NULL,
            typ TEXT DEFAULT 'info',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS einsaetze (
            id TEXT PRIMARY KEY,
            nummer TEXT DEFAULT '',
            art TEXT DEFAULT '',
            dringlichkeit TEXT DEFAULT '',
            patient_name TEXT DEFAULT '',
            patient_adresse TEXT DEFAULT '',
            patient_plz TEXT DEFAULT '',
            patient_ort TEXT DEFAULT '',
            patient_geburt TEXT DEFAULT '',
            patient_sv TEXT DEFAULT '',
            patient_tel TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            schluessel TEXT DEFAULT '',
            adressinfo TEXT DEFAULT '',
            problem TEXT DEFAULT '',
            risiken TEXT DEFAULT '[]',
            allergien TEXT DEFAULT '',
            medikamente TEXT DEFAULT '',
            anordnungen TEXT DEFAULT '',
            qualifikation TEXT DEFAULT '',
            fahrzeug TEXT DEFAULT '',
            disponent TEXT DEFAULT '',
            datum TEXT DEFAULT '',
            zeit TEXT DEFAULT '',
            ang_name TEXT DEFAULT '',
            ang_tel TEXT DEFAULT '',
            notiz TEXT DEFAULT '',
            extra TEXT DEFAULT '{}',
            status TEXT DEFAULT 'alarmiert',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        # Migration: Zeitstempel-Spalten für Status-Übergänge
        for col in ('zeit_unterwegs', 'zeit_eingetroffen', 'zeit_beendet', 'zeit_angenommen'):
            try:
                db.execute(f'ALTER TABLE einsaetze ADD COLUMN {col} TEXT DEFAULT ""')
            except Exception:
                pass
        db.execute('''CREATE TABLE IF NOT EXISTS einsatz_nachrichten (
            id TEXT PRIMARY KEY,
            einsatz_id TEXT NOT NULL,
            sender TEXT DEFAULT 'pfleger',
            text TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS leitstelle_users (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            rolle TEXT DEFAULT 'disponent',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS fahrzeuge (
            name       TEXT PRIMARY KEY,
            typ        TEXT DEFAULT 'HKP',
            bundesland TEXT DEFAULT '',
            bezirk     TEXT DEFAULT '',
            aktiv      INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS vehicle_sessions (
            fahrzeug     TEXT PRIMARY KEY,
            caregiver_id TEXT DEFAULT '',
            caregiver_name TEXT DEFAULT '',
            dienstnummer TEXT DEFAULT '',
            eingeloggt_seit TEXT DEFAULT '',
            status TEXT DEFAULT 'bereit'
        )''')
        # Pfleger → Leitstelle Nachrichten
        db.execute('''CREATE TABLE IF NOT EXISTS nachrichten (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            von_name     TEXT DEFAULT '',
            von_dnr      TEXT DEFAULT '',
            fahrzeug     TEXT DEFAULT '',
            typ          TEXT DEFAULT 'nachricht',
            text         TEXT DEFAULT '',
            gelesen      INTEGER DEFAULT 0,
            created_at   TEXT DEFAULT (datetime('now','localtime'))
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS patient_dokumente (
            id          TEXT PRIMARY KEY,
            patient_id  TEXT NOT NULL,
            typ         TEXT DEFAULT 'sonstiges',
            original_name TEXT DEFAULT '',
            stored_name TEXT DEFAULT '',
            beschreibung TEXT DEFAULT '',
            uploaded_by TEXT DEFAULT '',
            created_at  TEXT DEFAULT (datetime('now','localtime'))
        )''')
        # Migrations
        for migration in [
            'ALTER TABLE caregivers ADD COLUMN dienstnummer TEXT DEFAULT ""',
            'ALTER TABLE fahrzeuge ADD COLUMN bundesland TEXT DEFAULT ""',
            'ALTER TABLE fahrzeuge ADD COLUMN bezirk TEXT DEFAULT ""',
            'ALTER TABLE einsaetze ADD COLUMN patient_id TEXT DEFAULT ""',
            'ALTER TABLE rechnungen ADD COLUMN freitext TEXT DEFAULT ""',
            'ALTER TABLE leitstelle_users ADD COLUMN seiten_zugriff TEXT DEFAULT "[]"',
            'ALTER TABLE leitstelle_users ADD COLUMN notizen TEXT DEFAULT ""',
            'ALTER TABLE billing_users ADD COLUMN seiten_zugriff TEXT DEFAULT "[]"',
            'ALTER TABLE billing_users ADD COLUMN notizen TEXT DEFAULT ""',
        ]:
            try:
                db.execute(migration)
            except Exception:
                pass
        # Seed demo vehicles with Bundesland
        DEMO_FZ = [
            ('W-01',  'HKP', 'Wien',             '1. Bezirk'),
            ('W-02',  'HKP', 'Wien',             '2. Bezirk'),
            ('W-03',  'HKP', 'Wien',             '3. Bezirk'),
            ('NÖ-01', 'HKP', 'Niederösterreich', 'Baden'),
            ('NÖ-02', 'HKP', 'Niederösterreich', 'Mödling'),
            ('ST-01', 'HKP', 'Steiermark',       'Graz'),
            ('ST-02', 'HKP', 'Steiermark',       'Graz-Umgebung'),
            ('OÖ-01', 'HKP', 'Oberösterreich',   'Linz'),
            ('T-01',  'HKP', 'Tirol',            'Innsbruck'),
            ('S-01',  'HKP', 'Salzburg',         'Salzburg-Stadt'),
        ]
        for name, typ, bl, bz in DEMO_FZ:
            db.execute(
                'INSERT OR IGNORE INTO fahrzeuge (name,typ,bundesland,bezirk) VALUES (?,?,?,?)',
                (name, typ, bl, bz)
            )
            db.execute('INSERT OR IGNORE INTO vehicle_sessions (fahrzeug) VALUES (?)', (name,))
        # Keep old HKP-01..05, assign Wien if bundesland still empty
        for v in ['HKP-01','HKP-02','HKP-03','HKP-04','HKP-05']:
            db.execute('INSERT OR IGNORE INTO fahrzeuge (name,typ,bundesland,bezirk) VALUES (?,?,?,?)', (v,'HKP','Wien',''))
            db.execute("UPDATE fahrzeuge SET bundesland='Wien' WHERE name=? AND (bundesland IS NULL OR bundesland='')", (v,))
            db.execute('INSERT OR IGNORE INTO vehicle_sessions (fahrzeug) VALUES (?)', (v,))
        # ── Billing: Verrechnungsstelle ──────────────────────────────────
        db.execute('''CREATE TABLE IF NOT EXISTS billing_users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            rolle TEXT DEFAULT 'verrechnungsstelle',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS leistungskatalog (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            beschreibung TEXT DEFAULT '',
            kategorie TEXT DEFAULT 'Allgemein',
            preis REAL DEFAULT 0.0,
            einheit TEXT DEFAULT 'Einsatz',
            mwst_prozent REAL DEFAULT 0.0,
            aktiv INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS rechnungen (
            id TEXT PRIMARY KEY,
            nummer TEXT NOT NULL UNIQUE,
            typ TEXT DEFAULT 'notdienst',
            layout TEXT DEFAULT 'akutplus',
            empfaenger_name TEXT DEFAULT '',
            empfaenger_adresse TEXT DEFAULT '',
            empfaenger_plz TEXT DEFAULT '',
            empfaenger_ort TEXT DEFAULT '',
            empfaenger_email TEXT DEFAULT '',
            einsatz_id TEXT DEFAULT '',
            positionen TEXT DEFAULT '[]',
            netto REAL DEFAULT 0,
            mwst REAL DEFAULT 0,
            brutto REAL DEFAULT 0,
            status TEXT DEFAULT 'entwurf',
            faellig_am TEXT DEFAULT '',
            notiz TEXT DEFAULT '',
            erstellt_von TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        # Demo billing user seed
        try:
            db.execute(
                'INSERT OR IGNORE INTO billing_users (id,name,email,password_hash,rolle) VALUES (?,?,?,?,?)',
                ['bu_demo', 'Verrechnungsstelle', 'verrechnungsstelle@akutplus.at',
                 hash_pw('Verrechnung1!'), 'verrechnungsstelle']
            )
        except Exception:
            pass
        # Leistungskatalog — Akut Plus Pflege Notdienst Preisliste (gültig ab April 2026)
        default_lk = [
            # ── Pflegeeinsätze ───────────────────────────────────────────────
            ('lk01','Hauskrankenpflegeeinsatz',
             '45–65 € je nach Aufwand und Tageszeit. Reguläre Pflegebetreuung zu Hause.',
             'Pflegeeinsatz',55.0,'Einsatz',0.0,10),
            ('lk02','Pflegeeinsatz (pflegerelevante Situation)',
             '45–65 € je nach Aufwand. Bei akut aufgetretenen pflegerelevanten Situationen.',
             'Pflegeeinsatz',55.0,'Einsatz',0.0,20),
            ('lk03','Palliativbegleitung',
             '45–65 € je Einsatz. Palliativ-Einsätze werden wöchentlich verrechnet.',
             'Palliativ',55.0,'Einsatz',0.0,30),
            # ── Telemedizinische Leistungen ──────────────────────────────────
            ('lk10','Erstvisite (Telemedizin)',
             'Telemedizinische Erstuntersuchung ab 130 €.',
             'Telemedizin',130.0,'Visite',0.0,100),
            ('lk11','Folgevisite (Telemedizin)',
             'Telemedizinische Folgeuntersuchung ab 95 €.',
             'Telemedizin',95.0,'Visite',0.0,110),
            ('lk12','Optionale Untersuchung: EKG',
             'Bei Folgevisite – Elektrokardiogramm.',
             'Telemedizin',30.0,'Einheit',0.0,120),
            ('lk13','Optionale Untersuchung: Ultraschall',
             'Bei Folgevisite – Sonographie.',
             'Telemedizin',50.0,'Einheit',0.0,130),
            ('lk14','Optionale Untersuchung: Blutgasanalyse',
             'Bei Folgevisite – Blutgasanalyse.',
             'Telemedizin',35.0,'Einheit',0.0,140),
            ('lk15','Technische Pauschale (inkl. Pflegeperson)',
             'Wird bei jeder Visite vom PFLEGENOTDIENST verrechnet.',
             'Telemedizin',70.0,'Visite',0.0,150),
            # ── Notdienst / Sonstige Kosten ──────────────────────────────────
            ('lk04','Akut-Einsatzgebühr',
             '90 € einmalig – für die schnelle Organisation und den Einsatz innerhalb von 24 Stunden.',
             'Notdienst',90.0,'einmalig',0.0,200),
            ('lk05','Alarmierungsgebühr',
             'Wird pro Einsatz zusätzlich verrechnet.',
             'Notdienst',3.50,'Einsatz',0.0,210),
            ('lk06','Fahrtkosten (ab dem 5. Kilometer)',
             '0,76 €/km ab dem 5. Kilometer ab Standort des Pflegepersonals.',
             'Notdienst',0.76,'km',0.0,220),
            ('lk07','Versorgung außerhalb regulärer Zeiten',
             'Reguläre Zeiten: Mo–Fr 06:00–18:00. Außerhalb gilt ein Aufschlag von 15 €.',
             'Notdienst',15.0,'Einsatz',0.0,230),
            ('lk08','Wochenend-/Feiertagszuschlag',
             '30 € (Samstag/Sonntag) bzw. 40 € (gesetzliche Feiertage).',
             'Notdienst',30.0,'Einsatz',0.0,240),
        ]
        for row in default_lk:
            try:
                db.execute(
                    'INSERT OR IGNORE INTO leistungskatalog (id,name,beschreibung,kategorie,preis,einheit,mwst_prozent,sort_order) '
                    'VALUES (?,?,?,?,?,?,?,?)',
                    row
                )
            except Exception:
                pass
        # Set dienstnummer on demo test user if missing
        db.execute(
            'UPDATE caregivers SET dienstnummer="PK-001" WHERE email="care@test.at" AND (dienstnummer IS NULL OR dienstnummer="")'
        )
        db.execute('''CREATE TABLE IF NOT EXISTS startseite_blocks (
            id TEXT PRIMARY KEY,
            titel TEXT DEFAULT '',
            inhalt TEXT DEFAULT '',
            bild_url TEXT DEFAULT '',
            link_text TEXT DEFAULT '',
            link_url TEXT DEFAULT '',
            typ TEXT DEFAULT 'info',
            aktiv INTEGER DEFAULT 1,
            reihenfolge INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        # ── Pflege-Portal ─────────────────────────────────────────────────────
        db.execute('''CREATE TABLE IF NOT EXISTS portal_bewerbungen (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT NOT NULL,
            telefon TEXT DEFAULT '',
            password_hash TEXT DEFAULT '',
            qualifikation TEXT DEFAULT '',
            erfahrung_jahre INTEGER DEFAULT 0,
            bezirk TEXT DEFAULT '',
            fahrzeug_pref TEXT DEFAULT '',
            dienst_arten TEXT DEFAULT '[]',
            adresse TEXT DEFAULT '',
            status TEXT DEFAULT 'ausstehend',
            token TEXT DEFAULT '',
            notizen TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS portal_dienste (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            datum TEXT NOT NULL,
            art TEXT NOT NULL,
            von TEXT DEFAULT '',
            bis TEXT DEFAULT '',
            fahrzeug TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            status TEXT DEFAULT 'eingetragen',
            notiz TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS portal_events (
            id TEXT PRIMARY KEY,
            titel TEXT NOT NULL,
            datum TEXT NOT NULL,
            von TEXT DEFAULT '',
            bis TEXT DEFAULT '',
            typ TEXT DEFAULT 'Schulung',
            beschreibung TEXT DEFAULT '',
            ort TEXT DEFAULT '',
            slots INTEGER DEFAULT 0,
            erstellt_von TEXT DEFAULT '',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS portal_event_anmeldungen (
            id TEXT PRIMARY KEY,
            event_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now','localtime')),
            UNIQUE(event_id, user_id)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS portal_info (
            id TEXT PRIMARY KEY,
            titel TEXT NOT NULL,
            text TEXT NOT NULL,
            typ TEXT DEFAULT 'info',
            erstellt_von TEXT DEFAULT '',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )''')
        # Seed demo portal user
        try:
            db.execute(
                '''INSERT OR IGNORE INTO portal_bewerbungen
                   (id,vorname,nachname,email,password_hash,qualifikation,bezirk,fahrzeug_pref,status)
                   VALUES (?,?,?,?,?,?,?,?,?)''',
                ['pb_demo','Maria','Kovač','care@test.at',
                 hashlib.sha256('Test1234!'.encode()).hexdigest(),
                 'DGKP','2. Bezirk','W-02','freigegeben']
            )
        except Exception:
            pass
        # Seed demo events
        for ev in [
            ('ev01','EKG-Grundkurs','2026-05-12','09:00','12:00','Schulung','Grundlagen der EKG-Ableitung und Interpretation.','Wien, Zentrale',8),
            ('ev02','Wundmanagement Update','2026-05-20','14:00','17:00','Schulung','Aktuelle Standards im Wundmanagement.','Wien, Zentrale',12),
            ('ev03','Teamabend Frühjahr 2026','2026-05-28','18:00','21:00','Event','Gemeinsamer Abend für alle Mitarbeiterinnen.','Wien, Gasthof zum Wohl',40),
        ]:
            try:
                db.execute('INSERT OR IGNORE INTO portal_events (id,titel,datum,von,bis,typ,beschreibung,ort,slots) VALUES (?,?,?,?,?,?,?,?,?)', ev)
            except Exception:
                pass
        # Seed demo info
        for inf in [
            ('inf01','Neue Dienstplanrichtlinie ab Juni','Ab Juni gilt die neue Richtlinie für Überstundenregelungen.','warning','Admin'),
            ('inf02','Pflichtschulung Brandschutz – Frist 31.05.','Alle Mitarbeiterinnen müssen bis 31. Mai die Brandschutzschulung absolviert haben.','wichtig','Admin'),
            ('inf03','Kollektivvertragliche Gehaltserhöhung ab 1. Juni','Wir freuen uns, eine Erhöhung von 4,2 % bekanntgeben zu können.','success','Admin'),
        ]:
            try:
                db.execute('INSERT OR IGNORE INTO portal_info (id,titel,text,typ,erstellt_von) VALUES (?,?,?,?,?)', inf)
            except Exception:
                pass
        # ── Pflegerpersonal-Abrechnung ────────────────────────────────────────
        db.execute('''CREATE TABLE IF NOT EXISTS pfleger_bereitschaft_saetze (
            art TEXT PRIMARY KEY,
            satz_eur REAL DEFAULT 0.0,
            beschreibung TEXT DEFAULT ''
        )''')
        for art, satz, beschr in [
            ('Frühdienst',  65.00, 'Bereitschaftszulage 06:00–14:00'),
            ('Spätdienst',  70.00, 'Bereitschaftszulage 14:00–22:00'),
            ('Nachtdienst', 85.00, 'Bereitschaftszulage 22:00–06:00'),
        ]:
            db.execute(
                'INSERT OR IGNORE INTO pfleger_bereitschaft_saetze (art,satz_eur,beschreibung) VALUES (?,?,?)',
                [art, satz, beschr]
            )
        # ── Billing-Einstellungen (Rechnungsfußzeile etc.) ───────────────────
        db.execute('''CREATE TABLE IF NOT EXISTS billing_settings (
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT ''
        )''')
        for k, v in {
            'ap_firma':   'Akut Plus PFLEGENOTDIENST GmbH',
            'ap_strasse': 'Musterstraße 1',
            'ap_plzort':  '1010 Wien',
            'ap_email':   'office@akutplus.at',
            'ap_web':     'www.akutplus.at',
            'ap_uid':     'ATU12345678',
            'ap_iban':    'AT12 0000 0000 0000 0000',
            'ap_bic':     'MUSTRAT',
            'nu_firma':   'Nursy GmbH',
            'nu_strasse': 'Plattformstraße 1',
            'nu_plzort':  '1010 Wien',
            'nu_email':   'office@nursy.at',
            'nu_web':     'www.nursy.at',
            'nu_uid':     'ATU87654321',
            'nu_iban':    'AT98 0000 0000 0000 0001',
            'nu_bic':     'NRSYATW1',
        }.items():
            db.execute('INSERT OR IGNORE INTO billing_settings (key,value) VALUES (?,?)', [k, v])
        db.commit()

def hash_pw(pw):
    return hashlib.sha256(pw.encode('utf-8')).hexdigest()

def row_to_dict(row):
    return dict(row) if row else None

# Initialize DB on module load so gunicorn workers also set up tables
init_db()


# ── Auth helpers ────────────────────────────────────────────────────────────

TEST_CARE = {
    'id': 'care_test', 'vorname': 'Test', 'nachname': 'Pfleger',
    'email': 'care@test.at', 'gender': 'm', 'dienstnummer': 'PK-001',
    'address': 'Teststraße 1', 'plz': '4020', 'ort': 'Linz', 'role': 'care'
}

TEST_LEITSTELLE = {
    'id': 'ls_test', 'vorname': 'Demo', 'nachname': 'Disponent',
    'email': 'leitstelle@test.at', 'rolle': 'disponent', 'role': 'leitstelle'
}


# ── API: Pflegekraft ────────────────────────────────────────────────────────

@app.route('/api/register/care', methods=['POST'])
def register_care():
    data = request.get_json(silent=True) or {}
    required = ['vorname', 'nachname', 'email', 'password']
    for f in required:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort muss mind. 8 Zeichen haben'}), 400

    uid = 'c' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO caregivers (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk) '
                'VALUES (?,?,?,?,?,?,?,?,?,?)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('gender',''), data.get('address',''),
                 data.get('plz',''), data.get('ort',''), data.get('bezirk','')]
            )
            db.commit()
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Diese E-Mail-Adresse ist bereits registriert'}), 409

    session['user_id']   = uid
    session['user_role'] = 'care'
    user = {'id': uid, 'vorname': data['vorname'], 'nachname': data['nachname'],
            'email': data['email'], 'role': 'care'}
    return jsonify({'ok': True, 'user': user})


@app.route('/api/login/care', methods=['POST'])
def login_care():
    data  = request.get_json(silent=True) or {}
    email = data.get('email', '').strip().lower()
    pw    = data.get('password', '')

    if email == 'care@test.at' and pw == 'Test1234!':
        session['user_id']   = 'care_test'
        session['user_role'] = 'care'
        return jsonify({'ok': True, 'user': TEST_CARE})

    with get_db() as db:
        row = db.execute(
            'SELECT * FROM caregivers WHERE email=? AND password_hash=?',
            [email, hash_pw(pw)]
        ).fetchone()

    if not row:
        return jsonify({'error': 'E-Mail oder Passwort falsch'}), 401

    session['user_id']   = row['id']
    session['user_role'] = 'care'
    user = {'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
            'email': row['email'], 'gender': row['gender'],
            'address': row['address'], 'plz': row['plz'], 'ort': row['ort'],
            'dienstnummer': row['dienstnummer'] or '', 'role': 'care'}
    return jsonify({'ok': True, 'user': user})


# ── Fahrzeug-Login ───────────────────────────────────────────────────────────

@app.route('/api/login/fahrzeug', methods=['POST'])
def login_fahrzeug():
    data = request.get_json(silent=True) or {}
    dnr  = data.get('dienstnummer', '').strip().upper()
    pw   = data.get('password', '')
    fz   = data.get('fahrzeug', '').strip()

    if not dnr or not pw or not fz:
        return jsonify({'error': 'Dienstnummer, Passwort und Fahrzeug erforderlich'}), 400

    # Demo account
    if dnr == 'PK-001' and pw == 'Test1234!':
        session['user_id']   = 'care_test'
        session['user_role'] = 'care'
        session['fahrzeug']  = fz
        user = dict(TEST_CARE); user['fahrzeug'] = fz
        _set_vehicle_session(fz, 'care_test', 'Test Pfleger', 'PK-001')
        return jsonify({'ok': True, 'user': user, 'token': _make_token('care', 'care_test')})

    with get_db() as db:
        row = db.execute(
            'SELECT * FROM caregivers WHERE dienstnummer=? AND password_hash=?',
            [dnr, hash_pw(pw)]
        ).fetchone()

    if not row:
        return jsonify({'error': 'Dienstnummer oder Passwort falsch'}), 401

    # Check fahrzeug exists
    with get_db() as db:
        fz_row = db.execute('SELECT name FROM fahrzeuge WHERE name=? AND aktiv=1', [fz]).fetchone()
    if not fz_row:
        return jsonify({'error': 'Fahrzeug nicht gefunden'}), 404

    session['user_id']   = row['id']
    session['user_role'] = 'care'
    session['fahrzeug']  = fz
    name = row['vorname'] + ' ' + row['nachname']
    _set_vehicle_session(fz, row['id'], name, dnr)
    user = {
        'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
        'email': row['email'], 'gender': row['gender'], 'dienstnummer': dnr,
        'fahrzeug': fz, 'role': 'care'
    }
    return jsonify({'ok': True, 'user': user, 'token': _make_token('care', row['id'])})


def _set_vehicle_session(fahrzeug, cid, name, dnr):
    import datetime
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    with get_db() as db:
        db.execute(
            'INSERT OR REPLACE INTO vehicle_sessions (fahrzeug,caregiver_id,caregiver_name,dienstnummer,eingeloggt_seit,status) '
            'VALUES (?,?,?,?,?,?)',
            [fahrzeug, cid, name, dnr, now, 'im Dienst']
        )
        db.commit()


@app.route('/api/fahrzeuge/abmelden', methods=['POST'])
def fahrzeug_abmelden():
    fz = session.get('fahrzeug') or (request.get_json(silent=True) or {}).get('fahrzeug', '')
    if fz:
        with get_db() as db:
            db.execute(
                'UPDATE vehicle_sessions SET caregiver_id="",caregiver_name="",dienstnummer="",eingeloggt_seit="",status="bereit" WHERE fahrzeug=?',
                [fz]
            )
            db.commit()
    session.clear()
    return jsonify({'ok': True})


@app.route('/api/fahrzeuge')
def get_fahrzeuge():
    bl_filter = request.args.get('bundesland', '').strip()
    with get_db() as db:
        sql = '''
            SELECT f.name, f.typ, f.bundesland, f.bezirk, f.aktiv,
                   COALESCE(vs.caregiver_name,"") AS caregiver_name,
                   COALESCE(vs.dienstnummer,"")   AS dienstnummer,
                   COALESCE(vs.eingeloggt_seit,"") AS eingeloggt_seit,
                   COALESCE(vs.status,"bereit")    AS status
            FROM fahrzeuge f
            LEFT JOIN vehicle_sessions vs ON f.name = vs.fahrzeug
            WHERE f.aktiv = 1
        '''
        params = []
        if bl_filter:
            sql += ' AND f.bundesland = ?'
            params.append(bl_filter)
        sql += ' ORDER BY f.bundesland, f.bezirk, f.name'
        rows = db.execute(sql, params).fetchall()
        # Also return distinct Bundesländer
        bl_rows = db.execute(
            "SELECT DISTINCT bundesland FROM fahrzeuge WHERE aktiv=1 AND bundesland!='' ORDER BY bundesland"
        ).fetchall()
    return jsonify({
        'ok': True,
        'fahrzeuge': [dict(r) for r in rows],
        'bundeslaender': [r['bundesland'] for r in bl_rows]
    })


@app.route('/api/fahrzeuge/alle')
def get_fahrzeuge_alle():
    """Admin: all vehicles incl. inactive."""
    uid = session.get('user_id'); role = session.get('user_role')
    if role not in ('admin', 'leitstelle') and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        rows = db.execute('''
            SELECT f.name, f.typ, f.bundesland, f.bezirk, f.aktiv,
                   COALESCE(vs.caregiver_name,"") AS caregiver_name,
                   COALESCE(vs.status,"bereit")    AS fz_status
            FROM fahrzeuge f
            LEFT JOIN vehicle_sessions vs ON f.name = vs.fahrzeug
            ORDER BY f.bundesland, f.bezirk, f.name
        ''').fetchall()
    return jsonify({'ok': True, 'fahrzeuge': [dict(r) for r in rows]})


@app.route('/api/fahrzeuge', methods=['POST'])
def add_fahrzeug():
    uid = session.get('user_id'); role = session.get('user_role')
    if role not in ('admin', 'leitstelle') and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    name       = data.get('name', '').strip().upper()
    typ        = data.get('typ', 'HKP').strip()[:20]
    bundesland = data.get('bundesland', '').strip()[:60]
    bezirk     = data.get('bezirk', '').strip()[:60]
    if not name:
        return jsonify({'error': 'Name erforderlich'}), 400
    with get_db() as db:
        try:
            db.execute('INSERT INTO fahrzeuge (name,typ,bundesland,bezirk) VALUES (?,?,?,?)',
                       [name, typ, bundesland, bezirk])
            db.execute('INSERT OR IGNORE INTO vehicle_sessions (fahrzeug) VALUES (?)', [name])
            db.commit()
        except Exception:
            return jsonify({'error': 'Fahrzeug existiert bereits'}), 409
    return jsonify({'ok': True, 'name': name})


@app.route('/api/fahrzeuge/<name>', methods=['PUT'])
def update_fahrzeug(name):
    uid = session.get('user_id'); role = session.get('user_role')
    if role not in ('admin', 'leitstelle') and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    fields, params = [], []
    for col in ('typ', 'bundesland', 'bezirk'):
        if col in data:
            fields.append(f'{col}=?')
            params.append(str(data[col])[:60])
    if 'aktiv' in data:
        fields.append('aktiv=?')
        params.append(1 if data['aktiv'] else 0)
    if not fields:
        return jsonify({'error': 'Keine Felder'}), 400
    params.append(name.upper())
    with get_db() as db:
        db.execute(f'UPDATE fahrzeuge SET {",".join(fields)} WHERE name=?', params)
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/fahrzeuge/<name>', methods=['DELETE'])
def delete_fahrzeug(name):
    uid = session.get('user_id'); role = session.get('user_role')
    if role not in ('admin',) and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        db.execute('DELETE FROM fahrzeuge WHERE name=?', [name.upper()])
        db.execute('DELETE FROM vehicle_sessions WHERE fahrzeug=?', [name.upper()])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/nachrichten', methods=['POST'])
def send_nachricht():
    data = request.get_json(silent=True) or {}
    text = (data.get('text') or '').strip()
    if not text:
        return jsonify({'error': 'Kein Text'}), 400
    typ      = (data.get('typ') or 'nachricht').strip()[:30]
    # Try to get sender info from session, then fallback to body
    me = session.get('user_id')
    von_name = data.get('von_name', session.get('user_name', '')).strip()[:80]
    von_dnr  = data.get('von_dnr',  '').strip().upper()[:20]
    fahrzeug = data.get('fahrzeug', '').strip().upper()[:20]
    with get_db() as db:
        db.execute(
            'INSERT INTO nachrichten (von_name,von_dnr,fahrzeug,typ,text) VALUES (?,?,?,?,?)',
            [von_name, von_dnr, fahrzeug, typ, text]
        )
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/nachrichten')
def get_nachrichten():
    uid  = session.get('user_id')
    role = session.get('user_role')
    # Leitstelle and admin can read all
    if role not in ('leitstelle', 'admin') and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    since_id = request.args.get('since', 0, type=int)
    with get_db() as db:
        rows = db.execute(
            'SELECT * FROM nachrichten WHERE id > ? ORDER BY id DESC LIMIT 100',
            [since_id]
        ).fetchall()
    return jsonify({'nachrichten': [dict(r) for r in rows]})

@app.route('/api/nachrichten/<int:nid>/gelesen', methods=['POST'])
def mark_nachricht_gelesen(nid):
    uid  = session.get('user_id')
    role = session.get('user_role')
    if role not in ('leitstelle', 'admin') and uid != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        db.execute('UPDATE nachrichten SET gelesen=1 WHERE id=?', [nid])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/caregivers/<cid>/dienstnummer', methods=['POST'])
def set_dienstnummer(cid):
    uid = session.get('user_id'); role = session.get('user_role')
    if uid != 'admin' and role != 'admin':
        return jsonify({'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    dnr  = data.get('dienstnummer', '').strip().upper()
    if not dnr:
        return jsonify({'error': 'Dienstnummer erforderlich'}), 400
    with get_db() as db:
        db.execute('UPDATE caregivers SET dienstnummer=? WHERE id=?', [dnr, cid])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/caregivers')
def list_caregivers():
    with get_db() as db:
        rows = db.execute(
            'SELECT id,vorname,nachname,email,gender,address,plz,ort,bezirk,created_at '
            'FROM caregivers ORDER BY created_at DESC'
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d['name'] = d['vorname'] + ' ' + d['nachname']
        d['role'] = 'care'
        result.append(d)
    return jsonify({'ok': True, 'caregivers': result})


# ── API: Patienten ──────────────────────────────────────────────────────────

@app.route('/api/register/patient', methods=['POST'])
def register_patient():
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400

    uid = 'p' + uuid.uuid4().hex[:8]
    pw  = data.get('password', '')
    ang = json.dumps(data.get('angehoerige', []))

    with get_db() as db:
        db.execute(
            'INSERT INTO patients (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk,birth,hauptgrund,haeufigkeit,angehoerige) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [uid, data['vorname'].strip(), data['nachname'].strip(),
             data.get('email','').strip().lower(),
             hash_pw(pw) if pw else '',
             data.get('gender',''), data.get('address',''),
             data.get('plz',''), data.get('ort',''), data.get('bezirk',''),
             data.get('birth',''), data.get('hauptgrund',''),
             data.get('haeufigkeit',''), ang]
        )
        db.commit()

    return jsonify({'ok': True, 'id': uid,
                    'name': data['vorname'] + ' ' + data['nachname']})


@app.route('/api/patients')
def list_patients():
    role = session.get('user_role') or session.get('leitstelle_role')
    if not role:
        tok = _token_from_request()
        if tok:
            role = tok.get('role')
    if role not in ('care', 'leitstelle', 'admin', 'billing'):
        return jsonify({'ok': False, 'error': 'Nicht angemeldet', 'patients': []}), 401
    with get_db() as db:
        rows = db.execute('SELECT * FROM patients ORDER BY created_at DESC').fetchall()
    result = []
    for r in rows:
        addr_parts = [r['address'], r['plz'], r['ort']]
        addr = ', '.join(p for p in addr_parts if p)
        result.append({
            'id': r['id'],
            'vorname': r['vorname'], 'nachname': r['nachname'],
            'name': r['vorname'] + ' ' + r['nachname'],
            'email': r['email'], 'gender': r['gender'],
            'address': addr, 'plz': r['plz'], 'ort': r['ort'],
            'birth': r['birth'],
            'hauptgrund': r['hauptgrund'],
            'haeufigkeit': r['haeufigkeit'],
            'active': True, 'source': 'db', 'visits': []
        })
    return jsonify({'ok': True, 'patients': result})


# ── API: Patientenakte ──────────────────────────────────────────────────────

def _patient_to_dict(r):
    addr_parts = [r['address'] if 'address' in r.keys() else '',
                  r['plz'] if 'plz' in r.keys() else '',
                  r['ort'] if 'ort' in r.keys() else '']
    return {
        'id': r['id'], 'vorname': r['vorname'], 'nachname': r['nachname'],
        'name': r['vorname'] + ' ' + r['nachname'],
        'gender': r['gender'] if 'gender' in r.keys() else '',
        'address': ', '.join(p for p in addr_parts if p),
        'plz': r['plz'] if 'plz' in r.keys() else '',
        'ort': r['ort'] if 'ort' in r.keys() else '',
        'birth': r['birth'] if 'birth' in r.keys() else '',
        'hauptgrund': r['hauptgrund'] if 'hauptgrund' in r.keys() else '',
        'haeufigkeit': r['haeufigkeit'] if 'haeufigkeit' in r.keys() else '',
        'angehoerige': json.loads(r['angehoerige'] if 'angehoerige' in r.keys() else '[]'),
    }

def _get_session_role_fahrzeug():
    role = session.get('user_role') or session.get('leitstelle_role')
    fahrzeug = session.get('fahrzeug')
    if not role:
        tok = _token_from_request()
        if tok:
            role = tok.get('role')
    return role, fahrzeug

def _care_has_einsatz_for_patient(db, fahrzeug, pid):
    row = db.execute(
        "SELECT id FROM einsaetze WHERE fahrzeug=? AND patient_id=? AND status NOT IN ('storniert')",
        (fahrzeug, pid)
    ).fetchone()
    return row is not None

@app.route('/api/patienten')
def patienten_suche():
    role, fahrzeug = _get_session_role_fahrzeug()
    if role == 'care':
        return jsonify({'ok': False, 'error': 'Kein Zugriff: Patientensuche nur für Leitstelle'}), 403
    name = request.args.get('name', '').strip()
    with get_db() as db:
        if name:
            like = '%' + name + '%'
            rows = db.execute(
                "SELECT * FROM patients WHERE (vorname||' '||nachname) LIKE ? OR nachname LIKE ? OR vorname LIKE ? ORDER BY nachname",
                (like, like, like)
            ).fetchall()
        else:
            rows = db.execute('SELECT * FROM patients ORDER BY nachname, vorname').fetchall()
    return jsonify({'ok': True, 'patients': [_patient_to_dict(r) for r in rows]})

@app.route('/api/patienten/<pid>')
def patient_detail(pid):
    role, fahrzeug = _get_session_role_fahrzeug()
    with get_db() as db:
        if role == 'care':
            if not fahrzeug or not _care_has_einsatz_for_patient(db, fahrzeug, pid):
                return jsonify({'ok': False, 'error': 'Kein Zugriff: Kein aktiver Einsatz für diesen Patienten auf diesem Fahrzeug'}), 403
        row = db.execute('SELECT * FROM patients WHERE id=?', (pid,)).fetchone()
    if not row:
        return jsonify({'ok': False, 'error': 'Patient nicht gefunden'}), 404
    return jsonify({'ok': True, 'patient': _patient_to_dict(row)})

@app.route('/api/patienten/<pid>/dokumente', methods=['GET'])
def list_dokumente(pid):
    role, fahrzeug = _get_session_role_fahrzeug()
    with get_db() as db:
        if role == 'care':
            if not fahrzeug or not _care_has_einsatz_for_patient(db, fahrzeug, pid):
                return jsonify({'ok': False, 'error': 'Kein Zugriff: Kein aktiver Einsatz für diesen Patienten auf diesem Fahrzeug'}), 403
        rows = db.execute(
            'SELECT * FROM patient_dokumente WHERE patient_id=? ORDER BY created_at DESC', (pid,)
        ).fetchall()
    docs = []
    for r in rows:
        docs.append({
            'id': r['id'], 'typ': r['typ'],
            'original_name': r['original_name'],
            'stored_name': r['stored_name'],
            'beschreibung': r['beschreibung'],
            'uploaded_by': r['uploaded_by'],
            'created_at': r['created_at'],
            'url': '/api/uploads/' + r['stored_name'],
        })
    return jsonify({'ok': True, 'dokumente': docs})

@app.route('/api/patienten/<pid>/dokumente', methods=['POST'])
def upload_dokument(pid):
    role, fahrzeug = _get_session_role_fahrzeug()
    with get_db() as db:
        if role == 'care':
            if not fahrzeug or not _care_has_einsatz_for_patient(db, fahrzeug, pid):
                return jsonify({'ok': False, 'error': 'Kein Zugriff: Kein aktiver Einsatz für diesen Patienten auf diesem Fahrzeug'}), 403
        patient = db.execute('SELECT id FROM patients WHERE id=?', (pid,)).fetchone()
    if not patient:
        return jsonify({'ok': False, 'error': 'Patient nicht gefunden'}), 404

    file = request.files.get('file')
    if not file or file.filename == '':
        return jsonify({'ok': False, 'error': 'Keine Datei angegeben'}), 400
    if not allowed_file(file.filename):
        return jsonify({'ok': False, 'error': 'Dateityp nicht erlaubt'}), 400

    original_name = file.filename
    ext = original_name.rsplit('.', 1)[-1].lower() if '.' in original_name else 'bin'
    doc_id = 'dok_' + uuid.uuid4().hex[:12]
    stored_name = doc_id + '.' + ext
    file.save(os.path.join(UPLOAD_DIR, stored_name))

    typ = request.form.get('typ', 'sonstiges')
    beschreibung = request.form.get('beschreibung', '')
    uploaded_by  = session.get('user_name') or session.get('user_id') or 'unbekannt'

    with get_db() as db:
        db.execute(
            'INSERT INTO patient_dokumente (id,patient_id,typ,original_name,stored_name,beschreibung,uploaded_by) VALUES (?,?,?,?,?,?,?)',
            (doc_id, pid, typ, original_name, stored_name, beschreibung, uploaded_by)
        )
        db.commit()
    return jsonify({'ok': True, 'id': doc_id, 'url': '/api/uploads/' + stored_name})

@app.route('/api/uploads/<path:filename>')
def serve_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.route('/api/patienten/dokumente/<doc_id>', methods=['DELETE'])
def delete_dokument(doc_id):
    with get_db() as db:
        row = db.execute('SELECT * FROM patient_dokumente WHERE id=?', (doc_id,)).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Dokument nicht gefunden'}), 404
        stored = row['stored_name']
        db.execute('DELETE FROM patient_dokumente WHERE id=?', (doc_id,))
        db.commit()
    try:
        os.remove(os.path.join(UPLOAD_DIR, stored))
    except Exception:
        pass
    return jsonify({'ok': True})


# ── API: Session / Me ───────────────────────────────────────────────────────

@app.route('/api/me')
def me():
    uid  = session.get('user_id')
    role = session.get('user_role')
    # Token-Fallback
    if not uid:
        tok = _token_from_request()
        if tok:
            uid  = tok['uid']
            role = tok['role']
            session['user_id']   = uid
            session['user_role'] = role
            # Restore fahrzeug from vehicle_sessions
            if role == 'care':
                with get_db() as db:
                    vs2 = db.execute('SELECT fahrzeug FROM vehicle_sessions WHERE caregiver_id=?', [uid]).fetchone()
                if vs2 and vs2['fahrzeug']:
                    session['fahrzeug'] = vs2['fahrzeug']
    if not uid:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    if uid == 'care_test':
        u = dict(TEST_CARE)
        u['fahrzeug'] = session.get('fahrzeug', '')
        return jsonify({'ok': True, 'user': u})
    if role == 'care':
        fz = session.get('fahrzeug', '')
        with get_db() as db:
            row = db.execute('SELECT * FROM caregivers WHERE id=?', [uid]).fetchone()
            vs  = db.execute('SELECT * FROM vehicle_sessions WHERE fahrzeug=?', [fz]).fetchone() if fz else None
        if row:
            return jsonify({'ok': True, 'user': {
                'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
                'name': (row['vorname'] or '') + ' ' + (row['nachname'] or ''),
                'email': row['email'], 'gender': row['gender'],
                'address': row['address'], 'plz': row['plz'], 'ort': row['ort'],
                'dienstnummer': row['dienstnummer'] or '',
                'fahrzeug': fz,
                'eingeloggt_seit': vs['eingeloggt_seit'] if vs else '',
                'role': 'care'
            }})
    return jsonify({'error': 'Sitzung abgelaufen'}), 401


@app.route('/api/logout', methods=['POST'])
def logout():
    fz = session.get('fahrzeug', '')
    if fz:
        with get_db() as db:
            db.execute(
                'UPDATE vehicle_sessions SET caregiver_id="",caregiver_name="",dienstnummer="",eingeloggt_seit="",status="bereit" WHERE fahrzeug=?',
                [fz]
            )
            db.commit()
    session.clear()
    return jsonify({'ok': True})


# ── API: Leitstelle Auth ─────────────────────────────────────────────────────

@app.route('/api/login/leitstelle', methods=['POST'])
def login_leitstelle():
    data  = request.get_json(silent=True) or {}
    email = data.get('email', '').strip().lower()
    pw    = data.get('password', '')

    if email == 'leitstelle@test.at' and pw == 'Leitstelle1!':
        session['leitstelle_id']   = 'ls_test'
        session['leitstelle_role'] = 'leitstelle'
        return jsonify({'ok': True, 'user': TEST_LEITSTELLE,
                        'token': _make_token('leitstelle', 'ls_test')})

    with get_db() as db:
        row = db.execute(
            'SELECT * FROM leitstelle_users WHERE email=? AND password_hash=? AND aktiv=1',
            [email, hash_pw(pw)]
        ).fetchone()

    if not row:
        return jsonify({'error': 'E-Mail oder Passwort falsch'}), 401

    session['leitstelle_id']   = row['id']
    session['leitstelle_role'] = 'leitstelle'
    user = {'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
            'email': row['email'], 'rolle': row['rolle'], 'role': 'leitstelle'}
    return jsonify({'ok': True, 'user': user,
                    'token': _make_token('leitstelle', str(row['id']))})


@app.route('/api/leitstelle/logout', methods=['POST'])
def leitstelle_logout():
    session.clear()
    return jsonify({'ok': True})


@app.route('/api/leitstelle/me')
def leitstelle_me():
    lid = session.get('leitstelle_id')
    if session.get('admin'):
        return jsonify({'ok': True, 'user': {'id': 'admin', 'vorname': 'Admin', 'nachname': '', 'role': 'admin', 'rolle': 'admin'}})
    if not lid:
        tok = _token_from_request()
        if tok and tok['role'] in ('leitstelle', 'admin'):
            lid = tok['uid']
        else:
            return jsonify({'error': 'Nicht angemeldet'}), 401
    if lid in ('ls_test', ''):
        return jsonify({'ok': True, 'user': TEST_LEITSTELLE})
    with get_db() as db:
        row = db.execute('SELECT * FROM leitstelle_users WHERE id=? AND aktiv=1', [lid]).fetchone()
    if not row:
        return jsonify({'error': 'Sitzung abgelaufen'}), 401
    import json as _j
    return jsonify({'ok': True, 'user': {
        'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
        'email': row['email'], 'rolle': row['rolle'], 'role': 'leitstelle',
        'seiten_zugriff': _j.loads(row['seiten_zugriff'] or '[]') if 'seiten_zugriff' in row.keys() else []
    }})


def require_leitstelle():
    if session.get('admin') or session.get('leitstelle_id'):
        return None
    tok = _token_from_request()
    if tok and tok['role'] in ('leitstelle', 'admin'):
        return None
    return jsonify({'error': 'Kein Zugriff'}), 403


# ── API: Anfragen ───────────────────────────────────────────────────────────

@app.route('/api/requests', methods=['POST'])
def create_request():
    data = request.get_json(silent=True) or {}
    patient_id = data.get('patient_id', '').strip()
    if not patient_id:
        return jsonify({'error': 'patient_id fehlt'}), 400

    # Fetch patient info from DB
    with get_db() as db:
        pat = db.execute('SELECT * FROM patients WHERE id=?', [patient_id]).fetchone()
    if not pat:
        return jsonify({'error': 'Patient nicht gefunden'}), 404

    rid = 'r' + uuid.uuid4().hex[:8]
    pat_name = pat['vorname'] + ' ' + pat['nachname']
    addr_parts = [pat['address'], pat['plz'], pat['ort']]
    pat_addr = ', '.join(p for p in addr_parts if p)
    anamnese = data.get('anamnese', {})
    pflegestufe = anamnese.get('pflegestufe', '') if isinstance(anamnese, dict) else ''
    frequenz = anamnese.get('frequenz', '') if isinstance(anamnese, dict) else ''

    with get_db() as db:
        db.execute(
            'INSERT INTO requests (id,patient_id,patient_name,patient_gender,patient_address,patient_plz,patient_ort,patient_birth,anamnese,pflegestufe,frequenz) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [rid, patient_id, pat_name, pat['gender'],
             pat_addr, pat['plz'], pat['ort'], pat['birth'],
             json.dumps(anamnese), pflegestufe, frequenz]
        )
        db.commit()

    return jsonify({'ok': True, 'id': rid})


@app.route('/api/requests/pending')
def list_pending_requests():
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM requests WHERE status='pending' ORDER BY created_at DESC"
        ).fetchall()
    result = []
    for r in rows:
        try:
            anamnese = json.loads(r['anamnese'] or '{}')
        except Exception:
            anamnese = {}
        result.append({
            'id': r['id'],
            'patient_id': r['patient_id'],
            'patient_name': r['patient_name'],
            'patient_gender': r['patient_gender'],
            'patient_address': r['patient_address'],
            'patient_plz': r['patient_plz'],
            'patient_ort': r['patient_ort'],
            'patient_birth': r['patient_birth'],
            'anamnese': anamnese,
            'pflegestufe': r['pflegestufe'],
            'frequenz': r['frequenz'],
            'status': r['status'],
            'created_at': r['created_at'],
        })
    return jsonify({'ok': True, 'requests': result})


@app.route('/api/requests/<rid>/accept', methods=['POST'])
def accept_request(rid):
    caregiver_id = session.get('user_id', '')
    with get_db() as db:
        row = db.execute("SELECT * FROM requests WHERE id=?", [rid]).fetchone()
        if not row:
            return jsonify({'error': 'Anfrage nicht gefunden'}), 404
        db.execute(
            "UPDATE requests SET status='accepted', caregiver_id=? WHERE id=?",
            [caregiver_id, rid]
        )
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/requests/<rid>/decline', methods=['POST'])
def decline_request(rid):
    with get_db() as db:
        row = db.execute("SELECT * FROM requests WHERE id=?", [rid]).fetchone()
        if not row:
            return jsonify({'error': 'Anfrage nicht gefunden'}), 404
        db.execute("UPDATE requests SET status='declined' WHERE id=?", [rid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin Auth ──────────────────────────────────────────────────────────────

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.get_json(silent=True) or {}
    pw = data.get('password', '')
    if pw == ADMIN_PASSWORD:
        session['admin'] = True
        return jsonify({'ok': True, 'token': _make_token('admin')})
    return jsonify({'error': 'Falsches Passwort'}), 401

@app.route('/api/admin/me')
def admin_me():
    if session.get('admin'):
        return jsonify({'ok': True})
    tok = _token_from_request()
    if tok and tok['role'] == 'admin':
        return jsonify({'ok': True})
    return jsonify({'ok': False}), 401

@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    session.clear()
    return jsonify({'ok': True})

def require_admin():
    if session.get('admin'):
        return None
    tok = _token_from_request()
    if tok and tok['role'] == 'admin':
        return None
    return jsonify({'error': 'Kein Zugriff'}), 403


# ── Admin: Pflegekräfte ──────────────────────────────────────────────────────

@app.route('/api/admin/caregivers')
def admin_caregivers():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute(
            'SELECT c.id, c.vorname, c.nachname, c.email, c.gender, c.ort, c.created_at, '
            'COALESCE(s.status,"active") as status, COALESCE(s.plan,"normal") as plan, COALESCE(s.notes,"") as notes '
            'FROM caregivers c LEFT JOIN caregiver_status s ON c.id=s.caregiver_id '
            'ORDER BY c.created_at DESC'
        ).fetchall()
    return jsonify({'ok': True, 'caregivers': [dict(r) for r in rows]})

@app.route('/api/admin/caregivers/<cid>/status', methods=['POST'])
def admin_set_caregiver_status(cid):
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    status = data.get('status', 'active')
    plan   = data.get('plan', 'normal')
    notes  = data.get('notes', '')
    with get_db() as db:
        db.execute(
            'INSERT INTO caregiver_status (caregiver_id, status, plan, notes, updated_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP) '
            'ON CONFLICT(caregiver_id) DO UPDATE SET status=excluded.status, plan=excluded.plan, notes=excluded.notes, updated_at=excluded.updated_at',
            [cid, status, plan, notes]
        )
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/caregivers/<cid>', methods=['DELETE'])
def admin_delete_caregiver(cid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM caregivers WHERE id=?', [cid])
        db.execute('DELETE FROM caregiver_status WHERE caregiver_id=?', [cid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Klienten (Patienten) ───────────────────────────────────────────────

@app.route('/api/admin/klienten')
def admin_list_klienten():
    err = require_admin()
    if err: return err
    q = request.args.get('q', '').strip()
    with get_db() as db:
        if q:
            like = f'%{q}%'
            rows = db.execute(
                "SELECT * FROM patients WHERE vorname LIKE ? OR nachname LIKE ? OR email LIKE ? OR ort LIKE ? "
                "ORDER BY created_at DESC",
                [like, like, like, like]
            ).fetchall()
        else:
            rows = db.execute('SELECT * FROM patients ORDER BY created_at DESC').fetchall()
        # Attach request counts
        result = []
        for r in rows:
            reqs = db.execute(
                "SELECT id, status, pflegestufe, frequenz, created_at FROM requests WHERE patient_id=? ORDER BY created_at DESC",
                [r['id']]
            ).fetchall()
            p = dict(r)
            p.pop('password_hash', None)
            p['anfragen'] = [dict(x) for x in reqs]
            p['anfragen_total']   = len(reqs)
            p['anfragen_pending'] = sum(1 for x in reqs if x['status'] == 'pending')
            result.append(p)
    return jsonify({'ok': True, 'klienten': result})


@app.route('/api/admin/klienten/<kid>', methods=['DELETE'])
def admin_delete_klient(kid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM requests WHERE patient_id=?', [kid])
        db.execute('DELETE FROM patients WHERE id=?', [kid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Dienste / Leitstelle ──────────────────────────────────────────────

@app.route('/api/admin/dienste')
def admin_list_dienste():
    err = require_admin()
    if err: return err
    datum = request.args.get('datum', '')
    with get_db() as db:
        if datum:
            rows = db.execute('SELECT * FROM dienste WHERE datum=? ORDER BY von', [datum]).fetchall()
        else:
            rows = db.execute('SELECT * FROM dienste ORDER BY datum DESC, von', []).fetchall()
    return jsonify({'ok': True, 'dienste': [dict(r) for r in rows]})

@app.route('/api/admin/dienste', methods=['POST'])
def admin_create_dienst():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    required = ['caregiver_id', 'caregiver_name', 'datum', 'von', 'bis']
    for f in required:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld {f} fehlt'}), 400
    did = 'd' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute(
            'INSERT INTO dienste (id, caregiver_id, caregiver_name, datum, von, bis, typ, fahrzeug, notiz) VALUES (?,?,?,?,?,?,?,?,?)',
            [did, data['caregiver_id'], data['caregiver_name'],
             data['datum'], data['von'], data['bis'],
             data.get('typ', 'bereitschaft'), data.get('fahrzeug', ''), data.get('notiz', '')]
        )
        db.commit()
    return jsonify({'ok': True, 'id': did})

@app.route('/api/admin/dienste/<did>', methods=['DELETE'])
def admin_delete_dienst(did):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM dienste WHERE id=?', [did])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Leitstelle-Benutzer ───────────────────────────────────────────────

@app.route('/api/admin/leitstelle-users')
def admin_list_leitstelle_users():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT id,vorname,nachname,email,rolle,aktiv,created_at FROM leitstelle_users ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'users': [dict(r) for r in rows]})

# ── Benutzerverwaltung (Admiral) ─────────────────────────────────────────────

@app.route('/api/admin/nutzer')
def admin_nutzer_list():
    err = require_admin()
    if err: return err
    import json as _j
    with get_db() as db:
        ls = db.execute(
            'SELECT id, vorname||" "||nachname as name, email, rolle, aktiv,'
            ' COALESCE(seiten_zugriff,"[]") as seiten_zugriff,'
            ' COALESCE(notizen,"") as notizen'
            ' FROM leitstelle_users ORDER BY vorname, nachname'
        ).fetchall()
        bu = db.execute(
            'SELECT id, name, email, rolle, aktiv,'
            ' COALESCE(seiten_zugriff,"[]") as seiten_zugriff,'
            ' COALESCE(notizen,"") as notizen'
            ' FROM billing_users ORDER BY name'
        ).fetchall()
    def row(r, typ):
        return {'id': r['id'], 'name': r['name'], 'email': r['email'],
                'rolle': r['rolle'], 'aktiv': bool(r['aktiv']),
                'seiten_zugriff': _j.loads(r['seiten_zugriff'] or '[]'),
                'notizen': r['notizen'], 'typ': typ}
    return jsonify({'ok': True,
                    'leitstelle': [row(r,'leitstelle') for r in ls],
                    'billing':    [row(r,'billing')    for r in bu]})


@app.route('/api/admin/nutzer/<typ>/<uid>', methods=['PUT'])
def admin_nutzer_update(typ, uid):
    err = require_admin()
    if err: return err
    import json as _j
    data = request.get_json(silent=True) or {}
    if typ == 'leitstelle':
        table = 'leitstelle_users'
    elif typ == 'billing':
        table = 'billing_users'
    else:
        return jsonify({'error': 'Unbekannter Typ'}), 400
    sets, vals = [], []
    if 'rolle' in data:
        sets.append('rolle=?'); vals.append(data['rolle'])
    if 'aktiv' in data:
        sets.append('aktiv=?'); vals.append(1 if data['aktiv'] else 0)
    if 'seiten_zugriff' in data:
        sets.append('seiten_zugriff=?'); vals.append(_j.dumps(data['seiten_zugriff'], ensure_ascii=False))
    if 'notizen' in data:
        sets.append('notizen=?'); vals.append(data['notizen'])
    if 'password' in data and data['password']:
        if len(data['password']) < 8:
            return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
        sets.append('password_hash=?'); vals.append(hash_pw(data['password']))
    if not sets:
        return jsonify({'error': 'Nichts zu aktualisieren'}), 400
    vals.append(uid)
    with get_db() as db:
        db.execute(f'UPDATE {table} SET {",".join(sets)} WHERE id=?', vals)
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/admin/nutzer/<typ>', methods=['POST'])
def admin_nutzer_create(typ):
    err = require_admin()
    if err: return err
    import json as _j
    data = request.get_json(silent=True) or {}
    pw = data.get('password', '').strip()
    if len(pw) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    rolle = data.get('rolle', 'disponent' if typ == 'leitstelle' else 'verrechnungsstelle')
    sz = _j.dumps(data.get('seiten_zugriff', []), ensure_ascii=False)
    notizen = data.get('notizen', '')
    if typ == 'leitstelle':
        vn = data.get('vorname', '').strip()
        nn = data.get('nachname', '').strip()
        em = data.get('email', '').strip().lower()
        if not vn or not nn or not em:
            return jsonify({'error': 'Vorname, Nachname und E-Mail erforderlich'}), 400
        uid = 'ls_' + __import__('uuid').uuid4().hex[:8]
        with get_db() as db:
            db.execute(
                'INSERT INTO leitstelle_users (id,vorname,nachname,email,password_hash,rolle,aktiv,seiten_zugriff,notizen)'
                ' VALUES (?,?,?,?,?,?,1,?,?)',
                [uid, vn, nn, em, hash_pw(pw), rolle, sz, notizen]
            )
            db.commit()
        return jsonify({'ok': True, 'id': uid})
    elif typ == 'billing':
        name = data.get('name', '').strip()
        em   = data.get('email', '').strip().lower()
        if not name or not em:
            return jsonify({'error': 'Name und E-Mail erforderlich'}), 400
        uid = 'bu_' + __import__('uuid').uuid4().hex[:8]
        with get_db() as db:
            db.execute(
                'INSERT INTO billing_users (id,name,email,password_hash,rolle,aktiv,seiten_zugriff,notizen)'
                ' VALUES (?,?,?,?,?,1,?,?)',
                [uid, name, em, hash_pw(pw), rolle, sz, notizen]
            )
            db.commit()
        return jsonify({'ok': True, 'id': uid})
    return jsonify({'error': 'Unbekannter Typ'}), 400


@app.route('/api/admin/nutzer/<typ>/<uid>', methods=['DELETE'])
def admin_nutzer_delete(typ, uid):
    err = require_admin()
    if err: return err
    if typ == 'leitstelle':
        table = 'leitstelle_users'
    elif typ == 'billing':
        table = 'billing_users'
    else:
        return jsonify({'error': 'Unbekannter Typ'}), 400
    with get_db() as db:
        db.execute(f'DELETE FROM {table} WHERE id=?', [uid])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/admin/leitstelle-users', methods=['POST'])
def admin_create_leitstelle_user():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname', 'email', 'password']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    uid = 'ls_' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO leitstelle_users (id,vorname,nachname,email,password_hash,rolle,aktiv) VALUES (?,?,?,?,?,?,1)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('rolle', 'disponent')]
            )
            db.commit()
    except Exception as ex:
        return jsonify({'error': str(ex)}), 409
    return jsonify({'ok': True, 'id': uid})

@app.route('/api/admin/leitstelle-users/<uid>', methods=['DELETE'])
def admin_delete_leitstelle_user(uid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM leitstelle_users WHERE id=?', [uid])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/leitstelle-users/<uid>/password', methods=['POST'])
def admin_reset_leitstelle_pw(uid):
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    pw = data.get('password', '').strip()
    if len(pw) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    with get_db() as db:
        db.execute('UPDATE leitstelle_users SET password_hash=? WHERE id=?', [hash_pw(pw), uid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Pfleger-Konten (Kurzerfassung) ────────────────────────────────────

@app.route('/api/admin/pfleger', methods=['POST'])
def admin_create_pfleger():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname', 'email', 'password']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    uid = 'c' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO caregivers (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('gender',''), data.get('address',''),
                 data.get('plz',''), data.get('ort',''), data.get('bezirk','')]
            )
            db.commit()
    except Exception as ex:
        return jsonify({'error': str(ex)}), 409
    return jsonify({'ok': True, 'id': uid})


# ── Admin: Nachrichten ───────────────────────────────────────────────────────

@app.route('/api/admin/messages')
def admin_list_messages():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT * FROM admin_messages ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'messages': [dict(r) for r in rows]})

@app.route('/api/admin/messages', methods=['POST'])
def admin_create_message():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    text = data.get('text', '').strip()
    if not text:
        return jsonify({'error': 'Text fehlt'}), 400
    mid = 'm' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute(
            'INSERT INTO admin_messages (id, text, typ, aktiv) VALUES (?,?,?,1)',
            [mid, text, data.get('typ', 'info')]
        )
        db.commit()
    return jsonify({'ok': True, 'id': mid})

@app.route('/api/admin/messages/<mid>', methods=['DELETE'])
def admin_delete_message(mid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM admin_messages WHERE id=?', [mid])
        db.commit()
    return jsonify({'ok': True})

# Public: aktive Meldungen fürs Dashboard
@app.route('/api/messages/active')
def public_active_messages():
    with get_db() as db:
        rows = db.execute('SELECT id, text, typ FROM admin_messages WHERE aktiv=1 ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'messages': [dict(r) for r in rows]})


# ── Admin: Stats ─────────────────────────────────────────────────────────────

@app.route('/api/admin/stats')
def admin_stats():
    err = require_admin()
    if err: return err
    with get_db() as db:
        cg_total  = db.execute('SELECT COUNT(*) FROM caregivers').fetchone()[0]
        cg_active = db.execute("SELECT COUNT(*) FROM caregivers c LEFT JOIN caregiver_status s ON c.id=s.caregiver_id WHERE COALESCE(s.status,'active')='active'").fetchone()[0]
        cg_locked = db.execute("SELECT COUNT(*) FROM caregiver_status WHERE status='locked'").fetchone()[0]
        pat_total = db.execute('SELECT COUNT(*) FROM patients').fetchone()[0]
        req_pend  = db.execute("SELECT COUNT(*) FROM requests WHERE status='pending'").fetchone()[0]
        dienste_today = db.execute("SELECT COUNT(*) FROM dienste WHERE datum=date('now')").fetchone()[0]
    return jsonify({'ok': True, 'stats': {
        'cg_total': cg_total, 'cg_active': cg_active, 'cg_locked': cg_locked,
        'pat_total': pat_total, 'req_pending': req_pend, 'dienste_today': dienste_today
    }})


# ── Einsätze API ─────────────────────────────────────────────────────────────

@app.route('/api/fahrzeuge/<name>/nachrichten', methods=['GET'])
def get_fahrzeug_nachrichten(name):
    """Return the message thread for the current active einsatz of a vehicle."""
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM einsaetze WHERE fahrzeug=? AND status NOT IN ('beendet','storniert') ORDER BY datum DESC, zeit DESC LIMIT 1",
            (name,)
        ).fetchone()
        if not row:
            return jsonify({'einsatz_id': None, 'nachrichten': []})
        eid = row['id']
        msgs = db.execute(
            "SELECT * FROM einsatz_nachrichten WHERE einsatz_id=? ORDER BY created_at ASC", (eid,)
        ).fetchall()
    return jsonify({'einsatz_id': eid, 'nachrichten': [row_to_dict(r) for r in msgs]})

@app.route('/api/fahrzeuge/<name>/nachrichten', methods=['POST'])
def send_fahrzeug_nachricht(name):
    """Send a message from Leitstelle to the active einsatz of a vehicle."""
    data = request.get_json(silent=True) or {}
    text = data.get('text', '').strip()
    if not text:
        return jsonify({'error': 'empty'}), 400
    with get_db() as db:
        row = db.execute(
            "SELECT id FROM einsaetze WHERE fahrzeug=? AND status NOT IN ('beendet','storniert') ORDER BY datum DESC, zeit DESC LIMIT 1",
            (name,)
        ).fetchone()
        if not row:
            return jsonify({'error': 'Kein aktiver Einsatz'}), 404
        eid = row['id']
        mid = 'msg_' + str(uuid.uuid4())[:8]
        db.execute(
            "INSERT INTO einsatz_nachrichten (id,einsatz_id,sender,text) VALUES (?,?,?,?)",
            (mid, eid, 'leitstelle', text)
        )
    return jsonify({'ok': True, 'id': mid, 'einsatz_id': eid})

@app.route('/api/einsaetze', methods=['GET'])
def list_einsaetze():
    with get_db() as db:
        rows = db.execute("SELECT * FROM einsaetze ORDER BY created_at DESC LIMIT 100").fetchall()
    result = []
    for row in rows:
        e = row_to_dict(row)
        e['risiken'] = json.loads(e.get('risiken') or '[]')
        e['extra']   = json.loads(e.get('extra')   or '{}')
        result.append(e)
    return jsonify(result)

@app.route('/api/einsaetze', methods=['POST'])
def create_einsatz():
    data = request.get_json(silent=True) or {}
    eid  = data.get('id') or ('e_' + str(uuid.uuid4())[:8])
    pname = data.get('patient_name', '').strip()
    with get_db() as db:
        pid_lookup = ''
        if pname:
            parts = pname.strip().split()
            if len(parts) >= 2:
                prow = db.execute(
                    "SELECT id FROM patients WHERE vorname=? AND nachname=?",
                    (parts[0], parts[-1])
                ).fetchone()
                if not prow:
                    like = '%' + pname + '%'
                    prow = db.execute(
                        "SELECT id FROM patients WHERE (vorname||' '||nachname) LIKE ?",
                        (like,)
                    ).fetchone()
            else:
                like = '%' + pname + '%'
                prow = db.execute(
                    "SELECT id FROM patients WHERE (vorname||' '||nachname) LIKE ?",
                    (like,)
                ).fetchone()
            if prow:
                pid_lookup = prow['id']
        db.execute(
            '''INSERT OR REPLACE INTO einsaetze
               (id,nummer,art,dringlichkeit,patient_name,patient_adresse,patient_plz,patient_ort,
                patient_geburt,patient_sv,patient_tel,bezirk,schluessel,adressinfo,
                problem,risiken,allergien,medikamente,anordnungen,qualifikation,
                fahrzeug,disponent,datum,zeit,ang_name,ang_tel,notiz,extra,status,patient_id)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (eid,
             data.get('nummer',''),   data.get('art',''),        data.get('dringlichkeit',''),
             pname, data.get('patient_adresse',''),
             data.get('patient_plz',''),  data.get('patient_ort',''),
             data.get('patient_geburt',''), data.get('patient_sv',''), data.get('patient_tel',''),
             data.get('bezirk',''),    data.get('schluessel',''), data.get('adressinfo',''),
             data.get('problem',''),   json.dumps(data.get('risiken',[])),
             data.get('allergien',''), data.get('medikamente',''), data.get('anordnungen',''),
             data.get('qualifikation',''), data.get('fahrzeug',''), data.get('disponent',''),
             data.get('datum',''),     data.get('zeit',''),
             data.get('ang_name',''),  data.get('ang_tel',''),
             data.get('notiz',''),     json.dumps(data.get('extra',{})),
             data.get('status','alarmiert'), pid_lookup))
        db.commit()
    return jsonify({'id': eid, 'ok': True, 'patient_id': pid_lookup})

@app.route('/api/einsaetze/aktuell')
def get_aktuell_einsatz():
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM einsaetze WHERE status NOT IN ('beendet','storniert') ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
    if not row:
        return jsonify(None)
    e = row_to_dict(row)
    e['risiken'] = json.loads(e.get('risiken') or '[]')
    e['extra']   = json.loads(e.get('extra')   or '{}')
    return jsonify(e)

@app.route('/api/einsaetze/<eid>')
def get_einsatz(eid):
    with get_db() as db:
        row = db.execute("SELECT * FROM einsaetze WHERE id=?", (eid,)).fetchone()
    if not row:
        return jsonify({'error': 'not found'}), 404
    e = row_to_dict(row)
    e['risiken'] = json.loads(e.get('risiken') or '[]')
    e['extra']   = json.loads(e.get('extra')   or '{}')
    return jsonify(e)

@app.route('/api/einsaetze/<eid>/status', methods=['POST'])
def update_einsatz_status(eid):
    import datetime as _dt
    data   = request.get_json(silent=True) or {}
    status = data.get('status','')
    if status not in ('alarmiert','angenommen','unterwegs','eingetroffen','beendet','einsatzbereit'):
        return jsonify({'error': 'invalid status'}), 400
    client_zeit = (data.get('zeit') or '').strip()
    import re as _re
    now = client_zeit if _re.match(r'^\d{2}:\d{2}$', client_zeit) else _dt.datetime.now().strftime('%H:%M')
    ts_col = {'angenommen': 'zeit_angenommen', 'unterwegs': 'zeit_unterwegs', 'eingetroffen': 'zeit_eingetroffen', 'beendet': 'zeit_beendet'}.get(status)
    with get_db() as db:
        if ts_col:
            db.execute(f"UPDATE einsaetze SET status=?, {ts_col}=? WHERE id=?", (status, now, eid))
        else:
            db.execute("UPDATE einsaetze SET status=? WHERE id=?", (status, eid))
        row = db.execute("SELECT status,zeit_angenommen,zeit_unterwegs,zeit_eingetroffen,zeit_beendet FROM einsaetze WHERE id=?", (eid,)).fetchone()
    r = dict(row) if row else {}
    return jsonify({'ok': True, 'status': status,
                    'zeit_angenommen':  r.get('zeit_angenommen',''),
                    'zeit_unterwegs':   r.get('zeit_unterwegs',''),
                    'zeit_eingetroffen':r.get('zeit_eingetroffen',''),
                    'zeit_beendet':     r.get('zeit_beendet','')})

@app.route('/api/einsaetze/<eid>/nachrichten', methods=['GET'])
def get_einsatz_nachrichten(eid):
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM einsatz_nachrichten WHERE einsatz_id=? ORDER BY created_at ASC", (eid,)
        ).fetchall()
    return jsonify([row_to_dict(r) for r in rows])

@app.route('/api/einsaetze/<eid>/nachrichten', methods=['POST'])
def send_einsatz_nachricht(eid):
    data   = request.get_json(silent=True) or {}
    text   = data.get('text','').strip()
    if not text:
        return jsonify({'error': 'empty'}), 400
    sender = data.get('sender','pfleger')
    mid    = 'msg_' + str(uuid.uuid4())[:8]
    with get_db() as db:
        db.execute(
            "INSERT INTO einsatz_nachrichten (id,einsatz_id,sender,text) VALUES (?,?,?,?)",
            (mid, eid, sender, text)
        )
    return jsonify({'ok': True, 'id': mid})


@app.route('/api/auftraege')
def get_auftraege():
    """Return all einsaetze assigned to the current vehicle session."""
    fahrzeug = session.get('fahrzeug', '')
    # Token-Fallback: falls Session abgelaufen, Token aus Header prüfen
    if not fahrzeug:
        tok = _token_from_request()
        if tok:
            with get_db() as db:
                vs = db.execute(
                    'SELECT fahrzeug FROM vehicle_sessions WHERE caregiver_id=?',
                    (tok['uid'],)
                ).fetchone()
            if vs and vs['fahrzeug']:
                fahrzeug = vs['fahrzeug']
                # Session neu setzen
                session['fahrzeug']  = fahrzeug
                session['user_id']   = tok['uid']
                session['user_role'] = tok['role']
    if not fahrzeug:
        return jsonify({'error': 'Nicht angemeldet', 'auftraege': []}), 200
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM einsaetze WHERE fahrzeug=? ORDER BY datum DESC, zeit DESC LIMIT 200",
            (fahrzeug,)
        ).fetchall()
        if not rows:
            # Seed demo data for this vehicle so the page isn't empty
            import uuid as _uuid, datetime as _dt
            today = _dt.date.today().isoformat()
            demos = [
                (_uuid.uuid4().hex[:8], fahrzeug, 'Wundversorgung',    'geplant',  'Wagner Franz',     'Mariahilfer Str. 80, 1060 Wien',  '07:30', 'Chronische Wunde – Verbandwechsel', 'alarmiert'),
                (_uuid.uuid4().hex[:8], fahrzeug, 'Körperpflege',      'geplant',  'Berger Maria',     'Währinger Str. 45, 1090 Wien',    '09:00', 'Grundpflege, Mobilisation',         'alarmiert'),
                (_uuid.uuid4().hex[:8], fahrzeug, 'Medikamentengabe',  'dringend', 'Hofmann Karl',     'Favoritenstr. 12, 1100 Wien',     '10:30', 'Insulingabe, BD-Kontrolle',         'alarmiert'),
                (_uuid.uuid4().hex[:8], fahrzeug, 'Vitalzeichenkontrolle', 'geplant', 'Müller Elisabeth', 'Praterstr. 7, 1020 Wien',     '12:00', 'RR, Puls, SpO2, Temperatur',        'alarmiert'),
            ]
            for (eid, fz, art, dring, pname, padr, zeit, prob, st) in demos:
                db.execute(
                    '''INSERT OR IGNORE INTO einsaetze
                       (id,nummer,art,dringlichkeit,patient_name,patient_adresse,
                        fahrzeug,datum,zeit,problem,status)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                    ('e_'+eid, 'E-'+today+'-'+eid[:4].upper(),
                     art, dring, pname, padr, fz, today, zeit, prob, st)
                )
            db.commit()
            rows = db.execute(
                "SELECT * FROM einsaetze WHERE fahrzeug=? ORDER BY datum DESC, zeit DESC LIMIT 200",
                (fahrzeug,)
            ).fetchall()
    result = []
    for row in rows:
        e = row_to_dict(row)
        e['risiken'] = json.loads(e.get('risiken') or '[]')
        e['extra']   = json.loads(e.get('extra')   or '{}')
        result.append(e)
    return jsonify({'ok': True, 'fahrzeug': fahrzeug, 'auftraege': result})


# ── Static files ────────────────────────────────────────────────────────────

# ══════════════════════════════════════════════════════════════════════════════
# BILLING / VERRECHNUNGSSTELLE API
# ══════════════════════════════════════════════════════════════════════════════

def require_billing():
    """Allow billing_users AND admin session."""
    if session.get('admin'):
        return None
    if session.get('billing_user_id'):
        return None
    tok = _token_from_request()
    if tok and tok.get('role') in ('billing', 'admin'):
        return None
    return jsonify({'error': 'Nicht angemeldet'}), 401


@app.route('/api/billing/login', methods=['POST'])
def billing_login():
    data  = request.get_json(silent=True) or {}
    email = data.get('email', '').strip().lower()
    pw    = data.get('password', '')
    # Allow admiral/admin password as bypass
    if pw == 'NursyAdmin2024!':
        session['billing_user_id'] = 'admin'
        return jsonify({'ok': True, 'user': {'id': 'admin', 'name': 'Admiral', 'rolle': 'admiral'}})
    with get_db() as db:
        row = db.execute(
            'SELECT * FROM billing_users WHERE email=? AND password_hash=? AND aktiv=1',
            [email, hash_pw(pw)]
        ).fetchone()
    if not row:
        return jsonify({'error': 'E-Mail oder Passwort falsch'}), 401
    session['billing_user_id'] = row['id']
    return jsonify({'ok': True, 'user': {
        'id': row['id'], 'name': row['name'], 'email': row['email'], 'rolle': row['rolle']
    }})


@app.route('/api/billing/logout', methods=['POST'])
def billing_logout():
    session.pop('billing_user_id', None)
    return jsonify({'ok': True})


@app.route('/api/billing/me')
def billing_me():
    bid = session.get('billing_user_id')
    if session.get('admin'):
        return jsonify({'ok': True, 'user': {'id': 'admin', 'name': 'Admiral', 'rolle': 'admiral'}})
    if not bid:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    if bid == 'admin':
        return jsonify({'ok': True, 'user': {'id': 'admin', 'name': 'Admiral', 'rolle': 'admiral'}})
    with get_db() as db:
        row = db.execute('SELECT * FROM billing_users WHERE id=? AND aktiv=1', [bid]).fetchone()
    if not row:
        return jsonify({'error': 'Sitzung abgelaufen'}), 401
    import json as _jj
    return jsonify({'ok': True, 'user': {
        'id': row['id'], 'name': row['name'], 'email': row['email'], 'rolle': row['rolle'],
        'seiten_zugriff': _jj.loads(row['seiten_zugriff'] or '[]') if 'seiten_zugriff' in row.keys() else []
    }})


# ── Leistungskatalog ──────────────────────────────────────────────────────────

@app.route('/api/preisliste')
def public_preisliste():
    """Public endpoint — Leitstelle can read pricing without billing login."""
    with get_db() as db:
        rows = db.execute(
            'SELECT id,name,beschreibung,kategorie,preis,einheit,mwst_prozent,sort_order '
            'FROM leistungskatalog WHERE aktiv=1 ORDER BY sort_order, name'
        ).fetchall()
    return jsonify({'ok': True, 'leistungen': [dict(r) for r in rows],
                    'gueltig_ab': 'April 2026'})


@app.route('/api/billing/leistungskatalog')
def billing_leistungskatalog_list():
    err = require_billing()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT * FROM leistungskatalog ORDER BY sort_order, name').fetchall()
    return jsonify({'ok': True, 'leistungen': [dict(r) for r in rows]})


@app.route('/api/billing/leistungskatalog', methods=['POST'])
def billing_leistungskatalog_create():
    err = require_billing()
    if err: return err
    data = request.get_json(silent=True) or {}
    lid  = 'lk_' + uuid.uuid4().hex[:8]
    with get_db() as db:
        max_sort = db.execute('SELECT COALESCE(MAX(sort_order),0)+1 FROM leistungskatalog').fetchone()[0]
        db.execute(
            'INSERT INTO leistungskatalog (id,name,beschreibung,kategorie,preis,einheit,mwst_prozent,aktiv,sort_order) '
            'VALUES (?,?,?,?,?,?,?,?,?)',
            [lid, data.get('name','Neue Leistung'), data.get('beschreibung',''),
             data.get('kategorie','Allgemein'), float(data.get('preis',0)),
             data.get('einheit','Einsatz'), float(data.get('mwst_prozent',0)),
             1, max_sort]
        )
        db.commit()
    return jsonify({'ok': True, 'id': lid})


@app.route('/api/billing/leistungskatalog/<lid>', methods=['PUT'])
def billing_leistungskatalog_update(lid):
    err = require_billing()
    if err: return err
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        db.execute(
            'UPDATE leistungskatalog SET name=?,beschreibung=?,kategorie=?,preis=?,einheit=?,mwst_prozent=?,aktiv=? WHERE id=?',
            [data.get('name',''), data.get('beschreibung',''), data.get('kategorie','Allgemein'),
             float(data.get('preis',0)), data.get('einheit','Einsatz'),
             float(data.get('mwst_prozent',0)), int(data.get('aktiv',1)), lid]
        )
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/billing/leistungskatalog/<lid>', methods=['DELETE'])
def billing_leistungskatalog_delete(lid):
    err = require_billing()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM leistungskatalog WHERE id=?', [lid])
        db.commit()
    return jsonify({'ok': True})


# ── Rechnungen ────────────────────────────────────────────────────────────────

def _next_re_nummer(db, prefix):
    year  = __import__('datetime').date.today().year
    like  = f'{prefix}-{year}-%'
    last  = db.execute("SELECT nummer FROM rechnungen WHERE nummer LIKE ? ORDER BY nummer DESC LIMIT 1", [like]).fetchone()
    if last:
        try:
            n = int(last['nummer'].split('-')[-1]) + 1
        except Exception:
            n = 1
    else:
        n = 1
    return f'{prefix}-{year}-{n:04d}'


@app.route('/api/billing/rechnungen')
def billing_rechnungen_list():
    err = require_billing()
    if err: return err
    typ = request.args.get('typ', '')
    with get_db() as db:
        if typ:
            rows = db.execute('SELECT * FROM rechnungen WHERE typ=? ORDER BY created_at DESC', [typ]).fetchall()
        else:
            rows = db.execute('SELECT * FROM rechnungen ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'rechnungen': [dict(r) for r in rows]})


@app.route('/api/billing/rechnungen/<rid>')
def billing_rechnung_get(rid):
    err = require_billing()
    if err: return err
    with get_db() as db:
        row = db.execute('SELECT * FROM rechnungen WHERE id=?', [rid]).fetchone()
    if not row:
        return jsonify({'error': 'Nicht gefunden'}), 404
    return jsonify({'ok': True, 'rechnung': dict(row)})


@app.route('/api/billing/rechnungen', methods=['POST'])
def billing_rechnungen_create():
    err = require_billing()
    if err: return err
    data   = request.get_json(silent=True) or {}
    rid    = 're_' + uuid.uuid4().hex[:10]
    typ    = data.get('typ', 'notdienst')
    layout = data.get('layout', 'akutplus')
    prefix = 'AP' if layout == 'akutplus' else 'NU'
    user_name = ''
    bid = session.get('billing_user_id', 'system')
    if bid and bid != 'admin':
        with get_db() as db:
            bu = db.execute('SELECT name FROM billing_users WHERE id=?', [bid]).fetchone()
            user_name = bu['name'] if bu else ''
    else:
        user_name = 'Admiral'

    positionen = data.get('positionen', [])
    netto   = sum(float(p.get('menge',1)) * float(p.get('preis',0)) for p in positionen)
    mwst_total = sum(float(p.get('menge',1)) * float(p.get('preis',0)) * float(p.get('mwst_prozent',0)) / 100 for p in positionen)
    brutto  = netto + mwst_total

    with get_db() as db:
        nummer = _next_re_nummer(db, prefix)
        db.execute(
            'INSERT INTO rechnungen (id,nummer,typ,layout,empfaenger_name,empfaenger_adresse,empfaenger_plz,'
            'empfaenger_ort,empfaenger_email,einsatz_id,positionen,netto,mwst,brutto,status,faellig_am,notiz,freitext,erstellt_von) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [rid, nummer, typ, layout,
             data.get('empfaenger_name',''), data.get('empfaenger_adresse',''),
             data.get('empfaenger_plz',''), data.get('empfaenger_ort',''),
             data.get('empfaenger_email',''), data.get('einsatz_id',''),
             __import__('json').dumps(positionen, ensure_ascii=False),
             round(netto,2), round(mwst_total,2), round(brutto,2),
             data.get('status','entwurf'), data.get('faellig_am',''),
             data.get('notiz',''), data.get('freitext',''), user_name]
        )
        db.commit()
    return jsonify({'ok': True, 'id': rid, 'nummer': nummer})


@app.route('/api/billing/rechnungen/<rid>', methods=['PUT'])
def billing_rechnungen_update(rid):
    err = require_billing()
    if err: return err
    data = request.get_json(silent=True) or {}
    positionen = data.get('positionen', [])
    netto      = sum(float(p.get('menge',1)) * float(p.get('preis',0)) for p in positionen)
    mwst_total = sum(float(p.get('menge',1)) * float(p.get('preis',0)) * float(p.get('mwst_prozent',0)) / 100 for p in positionen)
    brutto     = netto + mwst_total
    import json as _json
    with get_db() as db:
        db.execute(
            'UPDATE rechnungen SET empfaenger_name=?,empfaenger_adresse=?,empfaenger_plz=?,empfaenger_ort=?,'
            'empfaenger_email=?,positionen=?,netto=?,mwst=?,brutto=?,status=?,faellig_am=?,notiz=?,freitext=? WHERE id=?',
            [data.get('empfaenger_name',''), data.get('empfaenger_adresse',''),
             data.get('empfaenger_plz',''), data.get('empfaenger_ort',''),
             data.get('empfaenger_email',''), _json.dumps(positionen, ensure_ascii=False),
             round(netto,2), round(mwst_total,2), round(brutto,2),
             data.get('status','entwurf'), data.get('faellig_am',''), data.get('notiz',''),
             data.get('freitext',''), rid]
        )
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/billing/rechnungen/<rid>/status', methods=['POST'])
def billing_rechnung_status(rid):
    err = require_billing()
    if err: return err
    data   = request.get_json(silent=True) or {}
    status = data.get('status', '')
    if status not in ('entwurf','gesendet','bezahlt','storniert'):
        return jsonify({'error': 'Ungültiger Status'}), 400
    with get_db() as db:
        db.execute('UPDATE rechnungen SET status=? WHERE id=?', [status, rid])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/billing/rechnungen/<rid>', methods=['DELETE'])
def billing_rechnungen_delete(rid):
    err = require_billing()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM rechnungen WHERE id=?', [rid])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/billing/einsaetze-abgeschlossen')
def billing_einsaetze():
    """Return completed Einsätze for invoice generation, including patient address data."""
    err = require_billing()
    if err: return err
    with get_db() as db:
        rows = db.execute(
            "SELECT e.*, COALESCE(r.nummer,'') as rechnung_nummer, "
            "COALESCE(p.address,'') as pat_adresse, "
            "COALESCE(p.plz,'') as pat_plz, "
            "COALESCE(p.ort,'') as pat_ort, "
            "COALESCE(p.email,'') as pat_email "
            "FROM einsaetze e "
            "LEFT JOIN rechnungen r ON r.einsatz_id=e.id "
            "LEFT JOIN patients p ON p.id=e.patient_id "
            "WHERE e.status IN ('beendet') ORDER BY e.datum DESC, e.zeit DESC LIMIT 100"
        ).fetchall()
    return jsonify({'ok': True, 'einsaetze': [dict(r) for r in rows]})


def _map_rechnung_to_js(r):
    import json as _j
    try:
        pos = _j.loads(r['positionen'] or '[]')
    except Exception:
        pos = []
    lines = []
    for p in pos:
        bez    = p.get('bezeichnung') or p.get('name') or ''
        menge  = float(p.get('menge', 1))
        preis  = float(p.get('preis', 0))
        einheit = p.get('einheit', 'Einheit')
        lines.append({
            'label':  bez,
            'qty':    str(int(menge)) + '\u00a0' + einheit,
            'amount': round(menge * preis, 2)
        })
    status_map = {'bezahlt': 'paid', 'storniert': 'overdue'}
    js_status  = status_map.get(r['status'], 'open')
    created    = (r['created_at'] or '')[:10]
    return {
        'id':          r['nummer'],
        'patient':     r['empfaenger_name'],
        'period':      created,
        'invoiceDate': created,
        'dueDate':     r['faellig_am'] or '',
        'amount':      float(r['brutto']),
        'status':      js_status,
        'lines':       lines,
        '_server':     True
    }


@app.route('/api/my/rechnungen')
def my_rechnungen():
    """Return Nursy invoices for the currently logged-in care worker."""
    uid  = session.get('user_id')
    role = session.get('user_role')
    if not uid or role != 'care':
        return jsonify({'ok': True, 'rechnungen': []})
    if uid == 'care_test':
        email = 'care@test.at'
    else:
        with get_db() as db:
            row = db.execute('SELECT email FROM caregivers WHERE id=?', [uid]).fetchone()
        email = row['email'] if row else None
    if not email:
        return jsonify({'ok': True, 'rechnungen': []})
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM rechnungen WHERE layout='nursy' AND lower(empfaenger_email)=? ORDER BY created_at DESC",
            [email.lower()]
        ).fetchall()
    return jsonify({'ok': True, 'rechnungen': [_map_rechnung_to_js(r) for r in rows]})


@app.route('/api/nursy/rechnungen-by-email')
def nursy_rechnungen_by_email():
    """Return Nursy invoices for a given e-mail address (patient / client view)."""
    email = request.args.get('email', '').strip().lower()
    if not email:
        return jsonify({'ok': True, 'rechnungen': []})
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM rechnungen WHERE layout='nursy' AND lower(empfaenger_email)=? ORDER BY created_at DESC",
            [email]
        ).fetchall()
    return jsonify({'ok': True, 'rechnungen': [_map_rechnung_to_js(r) for r in rows]})


@app.route('/api/billing/stats')
def billing_stats():
    err = require_billing()
    if err: return err
    with get_db() as db:
        total_ap  = db.execute("SELECT COUNT(*) FROM rechnungen WHERE layout='akutplus'").fetchone()[0]
        total_nu  = db.execute("SELECT COUNT(*) FROM rechnungen WHERE layout='nursy'").fetchone()[0]
        offen_ap  = db.execute("SELECT COALESCE(SUM(brutto),0) FROM rechnungen WHERE layout='akutplus' AND status='gesendet'").fetchone()[0]
        offen_nu  = db.execute("SELECT COALESCE(SUM(brutto),0) FROM rechnungen WHERE layout='nursy' AND status='gesendet'").fetchone()[0]
        bezahlt   = db.execute("SELECT COALESCE(SUM(brutto),0) FROM rechnungen WHERE status='bezahlt'").fetchone()[0]
        entwuerfe = db.execute("SELECT COUNT(*) FROM rechnungen WHERE status='entwurf'").fetchone()[0]
        lk_count  = db.execute("SELECT COUNT(*) FROM leistungskatalog WHERE aktiv=1").fetchone()[0]
    return jsonify({'ok': True, 'stats': {
        'total_ap': total_ap, 'total_nu': total_nu,
        'offen_ap': round(offen_ap,2), 'offen_nu': round(offen_nu,2),
        'bezahlt': round(bezahlt,2), 'entwuerfe': entwuerfe,
        'lk_count': lk_count
    }})


# ── Startseite Content Blocks ────────────────────────────────────────────────

@app.route('/api/startseite/blocks')
def public_startseite_blocks():
    with get_db() as db:
        rows = db.execute(
            'SELECT id, titel, inhalt, bild_url, link_text, link_url, typ FROM startseite_blocks WHERE aktiv=1 ORDER BY reihenfolge ASC, created_at ASC'
        ).fetchall()
    return jsonify({'ok': True, 'blocks': [dict(r) for r in rows]})

@app.route('/api/admin/startseite-blocks')
def admin_list_startseite_blocks():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT * FROM startseite_blocks ORDER BY reihenfolge ASC, created_at ASC').fetchall()
    return jsonify({'ok': True, 'blocks': [dict(r) for r in rows]})

@app.route('/api/admin/startseite-blocks', methods=['POST'])
def admin_create_startseite_block():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    bid = 'sb' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute(
            'INSERT INTO startseite_blocks (id, titel, inhalt, bild_url, link_text, link_url, typ, aktiv, reihenfolge) VALUES (?,?,?,?,?,?,?,?,?)',
            [bid, data.get('titel',''), data.get('inhalt',''), data.get('bild_url',''),
             data.get('link_text',''), data.get('link_url',''),
             data.get('typ','info'), 1 if data.get('aktiv', True) else 0,
             int(data.get('reihenfolge', 0))]
        )
        db.commit()
    return jsonify({'ok': True, 'id': bid})

@app.route('/api/admin/startseite-blocks/<bid>', methods=['PUT'])
def admin_update_startseite_block(bid):
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        db.execute(
            'UPDATE startseite_blocks SET titel=?, inhalt=?, bild_url=?, link_text=?, link_url=?, typ=?, aktiv=?, reihenfolge=? WHERE id=?',
            [data.get('titel',''), data.get('inhalt',''), data.get('bild_url',''),
             data.get('link_text',''), data.get('link_url',''),
             data.get('typ','info'), 1 if data.get('aktiv', True) else 0,
             int(data.get('reihenfolge', 0)), bid]
        )
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/startseite-blocks/<bid>', methods=['DELETE'])
def admin_delete_startseite_block(bid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM startseite_blocks WHERE id=?', [bid])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/startseite-blocks/<bid>/toggle', methods=['POST'])
def admin_toggle_startseite_block(bid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('UPDATE startseite_blocks SET aktiv = 1 - aktiv WHERE id=?', [bid])
        db.commit()
        row = db.execute('SELECT aktiv FROM startseite_blocks WHERE id=?', [bid]).fetchone()
    return jsonify({'ok': True, 'aktiv': row['aktiv'] if row else 0})


@app.route('/')
def index():
    resp = send_from_directory(BASE_DIR, 'index.html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp

# ══════════════════════════════════════════════════════════════════════════════
# ── Pflege-Portal ─────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

def _get_portal_user():
    uid = session.get('portal_user_id')
    if not uid:
        return None
    with get_db() as db:
        row = db.execute('SELECT * FROM portal_bewerbungen WHERE id=? AND status="freigegeben"', [uid]).fetchone()
        if row:
            return {'id': row['id'], 'name': row['vorname']+' '+row['nachname'],
                    'email': row['email'], 'bezirk': row['bezirk'],
                    'qualifikation': row['qualifikation'], 'fahrzeug_pref': row['fahrzeug_pref']}
        row = db.execute('SELECT * FROM caregivers WHERE id=?', [uid]).fetchone()
        if row:
            return {'id': row['id'], 'name': row['vorname']+' '+row['nachname'],
                    'email': row['email'], 'bezirk': row.get('bezirk',''),
                    'qualifikation': 'DGKP', 'fahrzeug_pref': ''}
    return None

def _require_admin_or_admiral():
    if session.get('admin'):
        return True
    if session.get('leitstelle_role') in ('admiral', 'disponent'):
        return True
    return False

@app.route('/api/portal/login', methods=['POST'])
def portal_login():
    data = request.get_json(silent=True) or {}
    email = data.get('email','').strip().lower()
    pw    = data.get('password','')
    if not email or not pw:
        return jsonify({'ok': False, 'error': 'E-Mail und Passwort erforderlich'}), 400
    with get_db() as db:
        row = db.execute('SELECT * FROM portal_bewerbungen WHERE LOWER(email)=? AND status="freigegeben"', [email]).fetchone()
        if row and row['password_hash'] and hmac.compare_digest(hash_pw(pw), row['password_hash']):
            session['portal_user_id']   = row['id']
            session['portal_user_name'] = row['vorname'] + ' ' + row['nachname']
            return jsonify({'ok': True, 'name': session['portal_user_name']})
        row = db.execute('SELECT * FROM caregivers WHERE LOWER(email)=?', [email]).fetchone()
        if row and hmac.compare_digest(hash_pw(pw), row['password_hash']):
            session['portal_user_id']   = row['id']
            session['portal_user_name'] = row['vorname'] + ' ' + row['nachname']
            return jsonify({'ok': True, 'name': session['portal_user_name']})
    return jsonify({'ok': False, 'error': 'E-Mail oder Passwort falsch'}), 401

@app.route('/api/portal/logout', methods=['POST'])
def portal_logout():
    session.pop('portal_user_id', None)
    session.pop('portal_user_name', None)
    return jsonify({'ok': True})

@app.route('/api/portal/me')
def portal_me():
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False}), 401
    return jsonify({'ok': True, **u})

@app.route('/api/portal/registrieren', methods=['POST'])
def portal_registrieren():
    data = request.get_json(silent=True) or {}
    for f in ['vorname','nachname','email','password','bezirk','qualifikation']:
        if not data.get(f,'').strip():
            return jsonify({'ok': False, 'error': f'Feld "{f}" fehlt'}), 400
    bid   = 'pb_' + uuid.uuid4().hex[:8]
    token = uuid.uuid4().hex
    with get_db() as db:
        ex = db.execute('SELECT id FROM portal_bewerbungen WHERE LOWER(email)=?', [data['email'].lower()]).fetchone()
        if ex:
            return jsonify({'ok': False, 'error': 'E-Mail bereits registriert'}), 409
        db.execute(
            '''INSERT INTO portal_bewerbungen
               (id,vorname,nachname,email,telefon,password_hash,qualifikation,erfahrung_jahre,
                bezirk,fahrzeug_pref,dienst_arten,adresse,status,token)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            [bid, data['vorname'].strip(), data['nachname'].strip(),
             data['email'].strip().lower(), data.get('telefon',''),
             hash_pw(data['password']), data['qualifikation'],
             int(data.get('erfahrung_jahre', 0)),
             data['bezirk'], data.get('fahrzeug_pref',''),
             json.dumps(data.get('dienst_arten', [])),
             data.get('adresse',''), 'ausstehend', token]
        )
        db.commit()
    return jsonify({'ok': True, 'id': bid, 'token': token,
                    'link': f'/pflege-portal-bewerbung.html?token={token}'})

@app.route('/api/portal/bewerbung/<token>')
def portal_bewerbung_get(token):
    with get_db() as db:
        row = db.execute('SELECT id,vorname,nachname,email,qualifikation,bezirk,status FROM portal_bewerbungen WHERE token=?', [token]).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Ungültiger Link'}), 404
        return jsonify({'ok': True, 'bewerbung': dict(row)})

@app.route('/api/portal/bewerbung/<token>', methods=['POST'])
def portal_bewerbung_submit(token):
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        row = db.execute('SELECT id FROM portal_bewerbungen WHERE token=?', [token]).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Ungültiger Link'}), 404
        db.execute('UPDATE portal_bewerbungen SET notizen=?, status="gespräch" WHERE token=?',
                   [data.get('notizen',''), token])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/portal/dienste')
def portal_dienste_get():
    if not _get_portal_user():
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    monat = request.args.get('monat','')
    with get_db() as db:
        if monat:
            rows = db.execute('SELECT * FROM portal_dienste WHERE datum LIKE ? ORDER BY datum', [f'{monat}%']).fetchall()
        else:
            rows = db.execute('SELECT * FROM portal_dienste ORDER BY datum DESC LIMIT 300').fetchall()
    return jsonify({'ok': True, 'dienste': [dict(r) for r in rows]})

@app.route('/api/portal/dienste', methods=['POST'])
def portal_dienst_create():
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    data = request.get_json(silent=True) or {}
    for f in ['datum','art']:
        if not data.get(f,'').strip():
            return jsonify({'ok': False, 'error': f'Feld "{f}" fehlt'}), 400
    ART_ZEITEN = {
        'Tagdienst':   ('06:00','20:00'),
        'Nachtdienst': ('20:00','06:00'),
        'Frühdienst':  ('06:00','14:00'),
        'Spätdienst':  ('14:00','22:00'),
    }
    von, bis = ART_ZEITEN.get(data['art'],('',''))
    did = 'pd_' + uuid.uuid4().hex[:8]
    with get_db() as db:
        ex = db.execute(
            'SELECT id FROM portal_dienste WHERE user_id=? AND datum=? AND art=? AND status!="storniert"',
            [u['id'], data['datum'], data['art']]
        ).fetchone()
        if ex:
            return jsonify({'ok': False, 'error': 'Bereits für diesen Dienst eingetragen'}), 409
        db.execute(
            'INSERT INTO portal_dienste (id,user_id,user_name,datum,art,von,bis,fahrzeug,bezirk,notiz) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [did, u['id'], u['name'], data['datum'], data['art'],
             data.get('von',von), data.get('bis',bis),
             data.get('fahrzeug',''), data['bezirk'], data.get('notiz','')]
        )
        db.commit()
    return jsonify({'ok': True, 'id': did})

@app.route('/api/portal/dienste/<did>', methods=['DELETE'])
def portal_dienst_delete(did):
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        row = db.execute('SELECT * FROM portal_dienste WHERE id=?', [did]).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Nicht gefunden'}), 404
        if row['user_id'] != u['id'] and not _require_admin_or_admiral():
            return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
        db.execute('DELETE FROM portal_dienste WHERE id=?', [did])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/portal/events')
def portal_events_get():
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        events = db.execute('SELECT * FROM portal_events WHERE aktiv=1 ORDER BY datum').fetchall()
        result = []
        for ev in events:
            cnt = db.execute('SELECT COUNT(*) as c FROM portal_event_anmeldungen WHERE event_id=?', [ev['id']]).fetchone()['c']
            my  = db.execute('SELECT id FROM portal_event_anmeldungen WHERE event_id=? AND user_id=?', [ev['id'], u['id']]).fetchone()
            d = dict(ev); d['angemeldet_count'] = cnt; d['ich_angemeldet'] = bool(my)
            result.append(d)
    return jsonify({'ok': True, 'events': result})

@app.route('/api/portal/events/<eid>/anmelden', methods=['POST'])
def portal_event_anmelden(eid):
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        ev = db.execute('SELECT * FROM portal_events WHERE id=? AND aktiv=1', [eid]).fetchone()
        if not ev:
            return jsonify({'ok': False, 'error': 'Event nicht gefunden'}), 404
        cnt = db.execute('SELECT COUNT(*) as c FROM portal_event_anmeldungen WHERE event_id=?', [eid]).fetchone()['c']
        if ev['slots'] > 0 and cnt >= ev['slots']:
            return jsonify({'ok': False, 'error': 'Keine freien Plätze mehr'}), 409
        try:
            db.execute('INSERT INTO portal_event_anmeldungen (id,event_id,user_id,user_name) VALUES (?,?,?,?)',
                       ['ea_'+uuid.uuid4().hex[:8], eid, u['id'], u['name']])
            db.commit()
        except Exception:
            return jsonify({'ok': False, 'error': 'Bereits angemeldet'}), 409
    return jsonify({'ok': True})

@app.route('/api/portal/events/<eid>/anmelden', methods=['DELETE'])
def portal_event_abmelden(eid):
    u = _get_portal_user()
    if not u:
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        db.execute('DELETE FROM portal_event_anmeldungen WHERE event_id=? AND user_id=?', [eid, u['id']])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/portal/info')
def portal_info_get():
    if not _get_portal_user():
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        rows = db.execute('SELECT * FROM portal_info WHERE aktiv=1 ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'info': [dict(r) for r in rows]})

# ── Admin: Portal-Verwaltung ─────────────────────────────────────────────────

@app.route('/api/admin/portal/stats')
def admin_portal_stats():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        offen      = db.execute('SELECT COUNT(*) as c FROM portal_bewerbungen WHERE status="ausstehend"').fetchone()['c']
        freigeg    = db.execute('SELECT COUNT(*) as c FROM portal_bewerbungen WHERE status="freigegeben"').fetchone()['c']
        dienste    = db.execute('SELECT COUNT(*) as c FROM portal_dienste WHERE datum >= date("now")').fetchone()['c']
        events     = db.execute('SELECT COUNT(*) as c FROM portal_events WHERE aktiv=1').fetchone()['c']
    return jsonify({'ok': True, 'offen': offen, 'freigegeben': freigeg, 'dienste': dienste, 'events': events})

@app.route('/api/admin/portal/fahrzeuge')
def admin_portal_fahrzeuge():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        rows = db.execute('SELECT * FROM fahrzeuge WHERE aktiv=1 ORDER BY name').fetchall()
    return jsonify({'ok': True, 'fahrzeuge': [dict(r) for r in rows]})

@app.route('/api/leitstelle/portal-dienste')
def leitstelle_portal_dienste():
    """Return today's and upcoming portal_dienste for Leitstelle view."""
    err = require_leitstelle()
    if err: return err
    datum = request.args.get('datum', '')
    if not datum:
        import datetime as _dt
        datum = _dt.date.today().isoformat()
    with get_db() as db:
        rows = db.execute(
            'SELECT user_name, art, fahrzeug, bezirk, datum, von, bis, notiz '
            'FROM portal_dienste WHERE datum=? AND status!="storniert" ORDER BY art, user_name',
            [datum]
        ).fetchall()
    return jsonify({'ok': True, 'datum': datum, 'dienste': [dict(r) for r in rows]})


@app.route('/api/portal/fahrzeuge')
def portal_fahrzeuge():
    if not _get_portal_user():
        return jsonify({'ok': False, 'error': 'Nicht angemeldet'}), 401
    with get_db() as db:
        rows = db.execute('SELECT name,bezirk,bundesland FROM fahrzeuge WHERE aktiv=1 ORDER BY name').fetchall()
    return jsonify({'ok': True, 'fahrzeuge': [dict(r) for r in rows]})

@app.route('/api/admin/portal/bewerbungen')
def admin_portal_bewerbungen():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        rows = db.execute('SELECT * FROM portal_bewerbungen ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'bewerbungen': [dict(r) for r in rows]})

@app.route('/api/admin/portal/bewerbungen/<bid>', methods=['PUT'])
def admin_portal_bewerbung_update(bid):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        row = db.execute('SELECT id FROM portal_bewerbungen WHERE id=?', [bid]).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Nicht gefunden'}), 404
        updates, vals = [], []
        for f in ('status','notizen','bezirk','fahrzeug_pref','qualifikation'):
            if f in data:
                updates.append(f'{f}=?'); vals.append(data[f])
        if updates:
            vals.append(bid)
            db.execute(f'UPDATE portal_bewerbungen SET {", ".join(updates)} WHERE id=?', vals)
            db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/portal/bewerbungen/<bid>/link-senden', methods=['POST'])
def admin_portal_link_senden(bid):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        row = db.execute('SELECT * FROM portal_bewerbungen WHERE id=?', [bid]).fetchone()
        if not row:
            return jsonify({'ok': False, 'error': 'Nicht gefunden'}), 404
        token = row['token'] or uuid.uuid4().hex
        if not row['token']:
            db.execute('UPDATE portal_bewerbungen SET token=? WHERE id=?', [token, bid])
            db.commit()
    link = f'/pflege-portal-bewerbung.html?token={token}'
    return jsonify({'ok': True, 'link': link, 'email': row['email'],
                    'name': row['vorname']+' '+row['nachname']})

@app.route('/api/admin/portal/dienste')
def admin_portal_dienste():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    monat = request.args.get('monat','')
    with get_db() as db:
        if monat:
            rows = db.execute('SELECT * FROM portal_dienste WHERE datum LIKE ? ORDER BY datum,art', [f'{monat}%']).fetchall()
        else:
            rows = db.execute('SELECT * FROM portal_dienste ORDER BY datum DESC,art LIMIT 500').fetchall()
    return jsonify({'ok': True, 'dienste': [dict(r) for r in rows]})

@app.route('/api/admin/portal/dienste/<did>', methods=['PUT'])
def admin_portal_dienst_update(did):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        updates, vals = [], []
        for f in ('datum','art','von','bis','fahrzeug','bezirk','status','notiz','user_name'):
            if f in data:
                updates.append(f'{f}=?'); vals.append(data[f])
        if updates:
            vals.append(did)
            db.execute(f'UPDATE portal_dienste SET {", ".join(updates)} WHERE id=?', vals)
            db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/portal/dienste/<did>', methods=['DELETE'])
def admin_portal_dienst_delete(did):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        db.execute('DELETE FROM portal_dienste WHERE id=?', [did])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/portal/events', methods=['GET'])
def admin_portal_events_get():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        events = db.execute('SELECT * FROM portal_events ORDER BY datum DESC').fetchall()
        result = []
        for ev in events:
            cnt = db.execute('SELECT COUNT(*) as c FROM portal_event_anmeldungen WHERE event_id=?', [ev['id']]).fetchone()['c']
            d = dict(ev); d['angemeldet_count'] = cnt; result.append(d)
    return jsonify({'ok': True, 'events': result})

@app.route('/api/admin/portal/events', methods=['POST'])
def admin_portal_event_create():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    if not data.get('titel') or not data.get('datum'):
        return jsonify({'ok': False, 'error': 'Titel und Datum erforderlich'}), 400
    eid = 'ev_' + uuid.uuid4().hex[:8]
    who = 'Admin' if session.get('admin') else session.get('leitstelle_name','Leitstelle')
    with get_db() as db:
        db.execute(
            'INSERT INTO portal_events (id,titel,datum,von,bis,typ,beschreibung,ort,slots,erstellt_von) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [eid, data['titel'], data['datum'], data.get('von',''), data.get('bis',''),
             data.get('typ','Schulung'), data.get('beschreibung',''), data.get('ort',''),
             int(data.get('slots',0)), who]
        )
        db.commit()
    return jsonify({'ok': True, 'id': eid})

@app.route('/api/admin/portal/events/<eid>', methods=['PUT'])
def admin_portal_event_update(eid):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        updates, vals = [], []
        for f in ('titel','datum','von','bis','typ','beschreibung','ort','slots','aktiv'):
            if f in data:
                updates.append(f'{f}=?'); vals.append(data[f])
        if updates:
            vals.append(eid)
            db.execute(f'UPDATE portal_events SET {", ".join(updates)} WHERE id=?', vals)
            db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/portal/events/<eid>', methods=['DELETE'])
def admin_portal_event_delete(eid):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        db.execute('DELETE FROM portal_events WHERE id=?', [eid])
        db.execute('DELETE FROM portal_event_anmeldungen WHERE event_id=?', [eid])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/portal/info', methods=['GET'])
def admin_portal_info_get():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        rows = db.execute('SELECT * FROM portal_info ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'info': [dict(r) for r in rows]})

@app.route('/api/admin/portal/info', methods=['POST'])
def admin_portal_info_create():
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    data = request.get_json(silent=True) or {}
    if not data.get('titel') or not data.get('text'):
        return jsonify({'ok': False, 'error': 'Titel und Text erforderlich'}), 400
    iid = 'inf_' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute('INSERT INTO portal_info (id,titel,text,typ,erstellt_von) VALUES (?,?,?,?,?)',
                   [iid, data['titel'], data['text'], data.get('typ','info'),
                    'Admin' if session.get('admin') else 'Leitstelle'])
        db.commit()
    return jsonify({'ok': True, 'id': iid})

@app.route('/api/admin/portal/info/<iid>', methods=['DELETE'])
def admin_portal_info_delete(iid):
    if not _require_admin_or_admiral():
        return jsonify({'ok': False, 'error': 'Kein Zugriff'}), 403
    with get_db() as db:
        db.execute('DELETE FROM portal_info WHERE id=?', [iid])
        db.commit()
    return jsonify({'ok': True})

# ── Pflegerpersonal-Abrechnung ─────────────────────────────────────────────

@app.route('/api/billing/pflegerpersonal/saetze')
def billing_pp_saetze_get():
    err = require_billing()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT * FROM pfleger_bereitschaft_saetze ORDER BY art').fetchall()
    return jsonify({'ok': True, 'saetze': [dict(r) for r in rows]})


@app.route('/api/billing/pflegerpersonal/saetze', methods=['PUT'])
def billing_pp_saetze_put():
    err = require_billing()
    if err: return err
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        for art, satz in data.items():
            db.execute('UPDATE pfleger_bereitschaft_saetze SET satz_eur=? WHERE art=?',
                       [float(satz), art])
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/billing/pflegerpersonal')
def billing_pflegerpersonal():
    err = require_billing()
    if err: return err
    monat = request.args.get('monat', datetime.now().strftime('%Y-%m'))
    # Allow UI to pass in ad-hoc rates (for preview before saving)
    rate_frueh  = float(request.args.get('frueh',  0) or 0)
    rate_spaet  = float(request.args.get('spaet',  0) or 0)
    rate_nacht  = float(request.args.get('nacht',  0) or 0)
    with get_db() as db:
        # Stored rates (fallback)
        saetze_rows = db.execute('SELECT * FROM pfleger_bereitschaft_saetze').fetchall()
        stored = {r['art']: r['satz_eur'] for r in saetze_rows}
        saetze = {
            'Frühdienst':  rate_frueh  if rate_frueh  else stored.get('Frühdienst',  65.0),
            'Spätdienst':  rate_spaet  if rate_spaet  else stored.get('Spätdienst',  70.0),
            'Nachtdienst': rate_nacht  if rate_nacht  else stored.get('Nachtdienst', 85.0),
        }
        # Einsatzvergütung per mission (lk01)
        lk = db.execute("SELECT preis FROM leistungskatalog WHERE id='lk01'").fetchone()
        einsatz_satz = lk['preis'] if lk else 55.0
        # All shifts in month
        dienste = db.execute(
            'SELECT * FROM portal_dienste WHERE datum LIKE ? ORDER BY datum, user_name',
            [f'{monat}%']
        ).fetchall()
        users = {}
        for d in dienste:
            uid = d['user_id']
            if uid not in users:
                users[uid] = {
                    'user_id': uid, 'user_name': d['user_name'],
                    'dienste': [], 'frueh': 0, 'spaet': 0, 'nacht': 0,
                    'einsaetze': 0, 'bereitschaftszulage': 0.0,
                }
            u = users[uid]
            # Count missions for this shift's vehicle on that date
            ez_count = 0
            if d['fahrzeug']:
                ez = db.execute(
                    "SELECT COUNT(*) as c FROM einsaetze WHERE fahrzeug=? AND DATE(COALESCE(updated_at,created_at))=?",
                    [d['fahrzeug'], d['datum']]
                ).fetchone()
                ez_count = ez['c'] if ez else 0
            art = d['art'] or ''
            satz = saetze.get(art, 0.0)
            u['dienste'].append({
                'id': d['id'], 'datum': d['datum'], 'art': art,
                'fahrzeug': d['fahrzeug'] or '', 'bezirk': d['bezirk'] or '',
                'von': d['von'] or '', 'bis': d['bis'] or '',
                'einsaetze': ez_count, 'bereitschaftszulage': satz,
            })
            u['einsaetze'] += ez_count
            u['bereitschaftszulage'] += satz
            if art == 'Frühdienst':  u['frueh']  += 1
            elif art == 'Spätdienst': u['spaet'] += 1
            elif art == 'Nachtdienst':u['nacht']  += 1
        result = []
        for u in users.values():
            u['einsatzverguetung'] = round(u['einsaetze'] * einsatz_satz, 2)
            u['bereitschaftszulage'] = round(u['bereitschaftszulage'], 2)
            u['gesamt'] = round(u['bereitschaftszulage'] + u['einsatzverguetung'], 2)
            u['einsatz_satz'] = einsatz_satz
            result.append(u)
        result.sort(key=lambda x: x['user_name'])
    return jsonify({'ok': True, 'pflegepersonal': result, 'saetze': saetze, 'monat': monat})


# ── Billing-Einstellungen (Fußzeile etc.) ──────────────────────────────────

@app.route('/api/billing/settings')
def billing_settings_get():
    err = require_billing()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT key, value FROM billing_settings').fetchall()
    return jsonify({'ok': True, 'settings': {r['key']: r['value'] for r in rows}})


@app.route('/api/billing/settings', methods=['PUT'])
def billing_settings_put():
    # Only admiral/admin may change settings
    is_admin = bool(session.get('admin'))
    if not is_admin:
        bid = session.get('billing_user_id')
        if bid == 'admin':
            is_admin = True
        elif bid:
            with get_db() as db:
                u = db.execute('SELECT rolle FROM billing_users WHERE id=?', [bid]).fetchone()
            is_admin = bool(u and u['rolle'] in ('admiral', 'admin'))
    if not is_admin:
        return jsonify({'ok': False, 'error': 'Nur Admiral darf Einstellungen ändern'}), 403
    data = request.get_json(silent=True) or {}
    with get_db() as db:
        for k, v in data.items():
            db.execute('INSERT OR REPLACE INTO billing_settings (key,value) VALUES (?,?)',
                       [k, str(v)])
        db.commit()
    return jsonify({'ok': True})


@app.route('/__mockup/', defaults={'subpath': ''})
@app.route('/__mockup/<path:subpath>')
def mockup_proxy(subpath):
    import urllib.request, urllib.error
    target = f'http://localhost:23636/__mockup/{subpath}'
    if request.query_string:
        target += '?' + request.query_string.decode()
    try:
        req = urllib.request.Request(target, headers={k: v for k, v in request.headers if k.lower() not in ('host',)})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = r.read()
            resp = app.response_class(data, status=r.status, content_type=r.headers.get('Content-Type', 'application/octet-stream'))
            for h in ('Cache-Control', 'ETag', 'Last-Modified', 'X-Content-Type-Options'):
                if r.headers.get(h):
                    resp.headers[h] = r.headers[h]
            return resp
    except urllib.error.HTTPError as e:
        return app.response_class(e.read(), status=e.code, content_type=e.headers.get('Content-Type', 'text/plain'))
    except Exception:
        return jsonify({'error': 'Mockup sandbox not reachable'}), 502

@app.route('/<path:filename>')
def static_files(filename):
    resp = send_from_directory(BASE_DIR, filename)
    if filename.endswith('.html'):
        resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        resp.headers['Pragma'] = 'no-cache'
        resp.headers['Expires'] = '0'
    return resp


# ── Entry point ─────────────────────────────────────────────────────────────

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5000))
    print(f'Nursy API + static server on port {port}', flush=True)
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
