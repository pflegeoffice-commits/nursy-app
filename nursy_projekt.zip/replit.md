# Nursy – Pflege-Marketplace Prototype (Akut Plus Pflegeportal)

## Overview
Nursy is a German-language care marketplace prototype. Stack: Flask/SQLite backend + plain HTML/CSS/JS frontend, port 5000.
Admin login: NursyAdmin2024! | Care login: care@test.at / Test1234!

## Key Pages
- `index.html` – landing page
- `leitstelle-ansicht.html` – Leitstelle (dispatch center) dashboard with Admiral floating-window layout
- `pfleger-einsatz.html` – mobile-first care worker app (receives alarms, shows mission + care plan + documentation + messages)
- `durchfuehrungsnachweis.html` – care documentation form
- `admin.html` – admin dashboard (billing + Pflege-Portal quick-access cards)
- `dashboard-care.html` – care worker dashboard (Pflege-Portal quick-access banner)
- `billing-login.html` / `billing.html` – Verrechnungsstelle login + dashboard
- `nutzer-verwaltung.html` – Admiral-only: interne Benutzer, Rollen & Seitenzugriff verwalten
- `pflege-portal-login.html` – Akut Plus Pflegeportal login (care@test.at / Test1234!)
- `pflege-portal.html` – Akut Plus Pflegeportal: month calendar, shift self-registration (Bezirk + Fahrzeug), events, info
- `pflege-portal-register.html` – 2-step registration form for new applicants
- `pflege-portal-bewerbung.html` – token-based detailed application form (sent via admin)
- `pflege-portal-admin.html` – admin/admiral management: Bewerbungen, Dienstplan, Events, Info
- `styles.css` – shared design system (CSS variables: --primary, --text, --muted, --panel, --panel2)

## Backend (server.py + nursy.db)
Flask routes + SQLite. Key tables:
- `caregivers`, `patients`, `requests`, `dienste`, `admin_messages`
- `einsaetze` – dispatch missions; `einsatz_nachrichten` – messages
- `billing_users`, `leistungskatalog`, `rechnungen` – billing system
- `portal_bewerbungen` – applicants (status: ausstehend/gespräch/freigegeben/abgelehnt, token for link)
- `portal_dienste` – self-registered shifts (datum, art, fahrzeug, bezirk, user_id)
- `portal_events` + `portal_event_anmeldungen` – training/events with registrations
- `portal_info` – info posts (typ: info/warning/wichtig/success)
- `pfleger_bereitschaft_saetze` – Bereitschaftszulage rates per shift type (Früh/Spät/Nacht)
- `billing_settings` – Rechnungsfußzeile key/value (ap_*/nu_* fields)
- `leitstelle_users.seiten_zugriff` / `billing_users.seiten_zugriff` – JSON-Array erlaubter Seiten-Keys per Benutzer

Key Portal API routes:
- `POST /api/portal/login|logout` · `GET /api/portal/me`
- `POST /api/portal/registrieren` – new applicant registration
- `GET/POST /api/portal/bewerbung/<token>` – token-based application form
- `GET/POST /api/portal/dienste` – shift calendar (self-registration with Bezirk + Fahrzeug)
- `DELETE /api/portal/dienste/<id>` – remove own shift
- `GET /api/portal/events` + `POST/DELETE /api/portal/events/<id>/anmelden`
- `GET /api/portal/info` · `GET /api/portal/fahrzeuge`
- `GET /api/admin/portal/bewerbungen` + `PUT /<id>` + `POST /<id>/link-senden`
- `GET/PUT/DELETE /api/admin/portal/dienste/<id>`
- `GET/POST/PUT/DELETE /api/admin/portal/events/<id>`
- `GET/POST /api/admin/portal/info` + `DELETE /<id>`
- `GET /api/admin/portal/stats|fahrzeuge`
- `GET /api/billing/pflegerpersonal?monat=YYYY-MM&frueh=X&spaet=Y&nacht=Z` – Pfleger Abrechnung (Dienste + Einsätze + Bereitschaftszulage)
- `GET/PUT /api/billing/pflegerpersonal/saetze` – Bereitschaftszulage-Sätze verwalten
- `GET/PUT /api/billing/settings` – Rechnungsfußzeile (Admiral only)
- `GET /api/admin/nutzer` · `POST /api/admin/nutzer/<typ>` · `PUT|DELETE /api/admin/nutzer/<typ>/<id>` – Benutzerverwaltung

## Replit Setup
- Workflow `Start application` runs `python3 server.py` on port 5000.
- `--card: #ffffff` defined in leitstelle-ansicht.html :root (not in styles.css).
- Admiral floating window manager in leitstelle-ansicht.html (PANELS 0–5, STORE='nursy_ls_admiral_v5').
- Portal auth: `session['portal_user_id']` — checks portal_bewerbungen (freigegeben) then caregivers table.
- Admin/Admiral access: `_require_admin_or_admiral()` checks `session['admin']` OR `leitstelle_role` in (admiral, disponent).
- Demo portal user: care@test.at / Test1234! (pb_demo, status=freigegeben, 2. Bezirk, W-02).
