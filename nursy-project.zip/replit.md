# Nursy – Pflege-Marketplace Prototype

## Overview
Nursy is a German-language care marketplace prototype. Stack: Flask/SQLite backend + plain HTML/CSS/JS frontend, port 5000.
Admin login: NursyAdmin2024! | Care login: care@test.at / Test1234!

## Key Pages
- `index.html` – landing page
- `leitstelle-ansicht.html` – Leitstelle (dispatch center) dashboard with Admiral floating-window layout
- `pfleger-einsatz.html` – mobile-first care worker app (receives alarms, shows mission + care plan + documentation + messages)
- `durchfuehrungsnachweis.html` – care documentation form
- `admin.html` – admin dashboard
- `dashboard-care.html` – care worker dashboard
- `*.js` – per-page client-side scripts
- `styles.css` – shared design system (CSS variables: --primary, --text, --muted, --panel, --panel2, --card)

## Backend (server.py + nursy.db)
Flask routes + SQLite. Key tables:
- `caregivers`, `patients`, `requests`, `dienste`, `admin_messages`
- `einsaetze` – dispatch missions (id, nummer, art, dringlichkeit, patient_*, risiken, status, …)
- `einsatz_nachrichten` – messages between care worker and dispatch

Key API routes:
- `POST /api/einsaetze` – create/update einsatz (Leitstelle calls this on alarm)
- `GET /api/einsaetze/aktuell` – latest active einsatz (pfleger-einsatz.html uses this)
- `POST /api/einsaetze/<id>/status` – update status (alarmiert/unterwegs/eingetroffen/beendet/einsatzbereit)
- `GET/POST /api/einsaetze/<id>/nachrichten` – messages

## Replit Setup
- Workflow `Start application` runs `python3 server.py` on port 5000.
- `--card: #ffffff` defined in leitstelle-ansicht.html :root (not in styles.css).
- Admiral floating window manager in leitstelle-ansicht.html (PANELS 0–5, STORE='nursy_ls_admiral_v5').
