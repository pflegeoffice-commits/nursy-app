#!/usr/bin/env python3
import os, json, uuid, hashlib, hmac, time
from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, 'nursy.db')

app = Flask(__name__, static_folder=BASE_DIR)
app.secret_key = os.environ.get('SECRET_KEY', 'nursy-dev-secret-2024')
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# When running behind Replit's HTTPS proxy, use Secure + SameSite=None so that
# session cookies are forwarded correctly even inside cross-origin iframes.
_is_https = bool(
    os.environ.get('REPLIT_DEPLOYMENT') or
    os.environ.get('REPLIT_DEV_DOMAIN') or
    os.environ.get('REPLIT_DOMAINS')
)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE']   = _is_https
app.config['SESSION_COOKIE_SAMESITE'] = 'None' if _is_https else 'Lax'


# ── DB ─────────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

ADMIN_PASSWORD = 'NursyAdmin2024!'

# ── Token Auth (fallback for environments where cookies fail) ────────────────

def _make_token(role, uid=''):
    ts   = str(int(time.time()))
    data = f"{role}|{uid}|{ts}"
    sig  = hmac.new(app.secret_key.encode(), data.encode(), 'sha256').hexdigest()
    return f"{data}|{sig}"

def _verify_token(token, max_age=86400 * 7):
    try:
        parts = token.split('|')
        if len(parts) != 4:
            return None
        role, uid, ts, sig = parts
        if time.time() - int(ts) > max_age:
            return None
        data     = f"{role}|{uid}|{ts}"
        expected = hmac.new(app.secret_key.encode(), data.encode(), 'sha256').hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        return {'role': role, 'uid': uid}
    except Exception:
        return None

def _token_from_request():
    auth = request.headers.get('X-Nursy-Token', '')
    if auth:
        return _verify_token(auth)
    return None

def init_db():
    with get_db() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS caregivers (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            gender TEXT DEFAULT '',
            address TEXT DEFAULT '',
            plz TEXT DEFAULT '',
            ort TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS patients (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT DEFAULT '',
            password_hash TEXT DEFAULT '',
            gender TEXT DEFAULT '',
            address TEXT DEFAULT '',
            plz TEXT DEFAULT '',
            ort TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            birth TEXT DEFAULT '',
            hauptgrund TEXT DEFAULT '',
            haeufigkeit TEXT DEFAULT '',
            angehoerige TEXT DEFAULT '[]',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            patient_id TEXT NOT NULL,
            patient_name TEXT NOT NULL,
            patient_gender TEXT DEFAULT '',
            patient_address TEXT DEFAULT '',
            patient_plz TEXT DEFAULT '',
            patient_ort TEXT DEFAULT '',
            patient_birth TEXT DEFAULT '',
            patient_data TEXT DEFAULT '{}',
            anamnese TEXT DEFAULT '{}',
            pflegestufe TEXT DEFAULT '',
            frequenz TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            caregiver_id TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS caregiver_status (
            caregiver_id TEXT PRIMARY KEY,
            status TEXT DEFAULT 'active',
            plan TEXT DEFAULT 'normal',
            notes TEXT DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS dienste (
            id TEXT PRIMARY KEY,
            caregiver_id TEXT NOT NULL,
            caregiver_name TEXT NOT NULL,
            datum TEXT NOT NULL,
            von TEXT NOT NULL,
            bis TEXT NOT NULL,
            typ TEXT DEFAULT 'bereitschaft',
            fahrzeug TEXT DEFAULT '',
            notiz TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS admin_messages (
            id TEXT PRIMARY KEY,
            text TEXT NOT NULL,
            typ TEXT DEFAULT 'info',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS einsaetze (
            id TEXT PRIMARY KEY,
            nummer TEXT DEFAULT '',
            art TEXT DEFAULT '',
            dringlichkeit TEXT DEFAULT '',
            patient_name TEXT DEFAULT '',
            patient_adresse TEXT DEFAULT '',
            patient_plz TEXT DEFAULT '',
            patient_ort TEXT DEFAULT '',
            patient_geburt TEXT DEFAULT '',
            patient_sv TEXT DEFAULT '',
            patient_tel TEXT DEFAULT '',
            bezirk TEXT DEFAULT '',
            schluessel TEXT DEFAULT '',
            adressinfo TEXT DEFAULT '',
            problem TEXT DEFAULT '',
            risiken TEXT DEFAULT '[]',
            allergien TEXT DEFAULT '',
            medikamente TEXT DEFAULT '',
            anordnungen TEXT DEFAULT '',
            qualifikation TEXT DEFAULT '',
            fahrzeug TEXT DEFAULT '',
            disponent TEXT DEFAULT '',
            datum TEXT DEFAULT '',
            zeit TEXT DEFAULT '',
            ang_name TEXT DEFAULT '',
            ang_tel TEXT DEFAULT '',
            notiz TEXT DEFAULT '',
            extra TEXT DEFAULT '{}',
            status TEXT DEFAULT 'alarmiert',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS einsatz_nachrichten (
            id TEXT PRIMARY KEY,
            einsatz_id TEXT NOT NULL,
            sender TEXT DEFAULT 'pfleger',
            text TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS leitstelle_users (
            id TEXT PRIMARY KEY,
            vorname TEXT NOT NULL,
            nachname TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            rolle TEXT DEFAULT 'disponent',
            aktiv INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )''')
        db.commit()

def hash_pw(pw):
    return hashlib.sha256(pw.encode('utf-8')).hexdigest()

def row_to_dict(row):
    return dict(row) if row else None

# Initialize DB on module load so gunicorn workers also set up tables
init_db()


# ── Auth helpers ────────────────────────────────────────────────────────────

TEST_CARE = {
    'id': 'care_test', 'vorname': 'Test', 'nachname': 'Pfleger',
    'email': 'care@test.at', 'gender': 'm',
    'address': 'Teststraße 1', 'plz': '4020', 'ort': 'Linz', 'role': 'care'
}

TEST_LEITSTELLE = {
    'id': 'ls_test', 'vorname': 'Demo', 'nachname': 'Disponent',
    'email': 'leitstelle@test.at', 'rolle': 'disponent', 'role': 'leitstelle'
}


# ── API: Pflegekraft ────────────────────────────────────────────────────────

@app.route('/api/register/care', methods=['POST'])
def register_care():
    data = request.get_json(silent=True) or {}
    required = ['vorname', 'nachname', 'email', 'password']
    for f in required:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort muss mind. 8 Zeichen haben'}), 400

    uid = 'c' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO caregivers (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk) '
                'VALUES (?,?,?,?,?,?,?,?,?,?)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('gender',''), data.get('address',''),
                 data.get('plz',''), data.get('ort',''), data.get('bezirk','')]
            )
            db.commit()
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Diese E-Mail-Adresse ist bereits registriert'}), 409

    session['user_id']   = uid
    session['user_role'] = 'care'
    user = {'id': uid, 'vorname': data['vorname'], 'nachname': data['nachname'],
            'email': data['email'], 'role': 'care'}
    return jsonify({'ok': True, 'user': user})


@app.route('/api/login/care', methods=['POST'])
def login_care():
    data  = request.get_json(silent=True) or {}
    email = data.get('email', '').strip().lower()
    pw    = data.get('password', '')

    if email == 'care@test.at' and pw == 'Test1234!':
        session['user_id']   = 'care_test'
        session['user_role'] = 'care'
        return jsonify({'ok': True, 'user': TEST_CARE})

    with get_db() as db:
        row = db.execute(
            'SELECT * FROM caregivers WHERE email=? AND password_hash=?',
            [email, hash_pw(pw)]
        ).fetchone()

    if not row:
        return jsonify({'error': 'E-Mail oder Passwort falsch'}), 401

    session['user_id']   = row['id']
    session['user_role'] = 'care'
    user = {'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
            'email': row['email'], 'gender': row['gender'],
            'address': row['address'], 'plz': row['plz'], 'ort': row['ort'],
            'role': 'care'}
    return jsonify({'ok': True, 'user': user})


@app.route('/api/caregivers')
def list_caregivers():
    with get_db() as db:
        rows = db.execute(
            'SELECT id,vorname,nachname,email,gender,address,plz,ort,bezirk,created_at '
            'FROM caregivers ORDER BY created_at DESC'
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d['name'] = d['vorname'] + ' ' + d['nachname']
        d['role'] = 'care'
        result.append(d)
    return jsonify({'ok': True, 'caregivers': result})


# ── API: Patienten ──────────────────────────────────────────────────────────

@app.route('/api/register/patient', methods=['POST'])
def register_patient():
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400

    uid = 'p' + uuid.uuid4().hex[:8]
    pw  = data.get('password', '')
    ang = json.dumps(data.get('angehoerige', []))

    with get_db() as db:
        db.execute(
            'INSERT INTO patients (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk,birth,hauptgrund,haeufigkeit,angehoerige) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [uid, data['vorname'].strip(), data['nachname'].strip(),
             data.get('email','').strip().lower(),
             hash_pw(pw) if pw else '',
             data.get('gender',''), data.get('address',''),
             data.get('plz',''), data.get('ort',''), data.get('bezirk',''),
             data.get('birth',''), data.get('hauptgrund',''),
             data.get('haeufigkeit',''), ang]
        )
        db.commit()

    return jsonify({'ok': True, 'id': uid,
                    'name': data['vorname'] + ' ' + data['nachname']})


@app.route('/api/patients')
def list_patients():
    with get_db() as db:
        rows = db.execute('SELECT * FROM patients ORDER BY created_at DESC').fetchall()
    result = []
    for r in rows:
        addr_parts = [r['address'], r['plz'], r['ort']]
        addr = ', '.join(p for p in addr_parts if p)
        result.append({
            'id': r['id'],
            'vorname': r['vorname'], 'nachname': r['nachname'],
            'name': r['vorname'] + ' ' + r['nachname'],
            'email': r['email'], 'gender': r['gender'],
            'address': addr, 'plz': r['plz'], 'ort': r['ort'],
            'birth': r['birth'],
            'hauptgrund': r['hauptgrund'],
            'haeufigkeit': r['haeufigkeit'],
            'active': True, 'source': 'db', 'visits': []
        })
    return jsonify({'ok': True, 'patients': result})


# ── API: Session / Me ───────────────────────────────────────────────────────

@app.route('/api/me')
def me():
    uid  = session.get('user_id')
    role = session.get('user_role')
    if not uid:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    if uid == 'care_test':
        return jsonify({'ok': True, 'user': TEST_CARE})
    if role == 'care':
        with get_db() as db:
            row = db.execute('SELECT * FROM caregivers WHERE id=?', [uid]).fetchone()
        if row:
            return jsonify({'ok': True, 'user': {
                'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
                'email': row['email'], 'gender': row['gender'],
                'address': row['address'], 'plz': row['plz'], 'ort': row['ort'],
                'role': 'care'
            }})
    return jsonify({'error': 'Sitzung abgelaufen'}), 401


@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'ok': True})


# ── API: Leitstelle Auth ─────────────────────────────────────────────────────

@app.route('/api/login/leitstelle', methods=['POST'])
def login_leitstelle():
    data  = request.get_json(silent=True) or {}
    email = data.get('email', '').strip().lower()
    pw    = data.get('password', '')

    if email == 'leitstelle@test.at' and pw == 'Leitstelle1!':
        session['leitstelle_id']   = 'ls_test'
        session['leitstelle_role'] = 'leitstelle'
        return jsonify({'ok': True, 'user': TEST_LEITSTELLE,
                        'token': _make_token('leitstelle', 'ls_test')})

    with get_db() as db:
        row = db.execute(
            'SELECT * FROM leitstelle_users WHERE email=? AND password_hash=? AND aktiv=1',
            [email, hash_pw(pw)]
        ).fetchone()

    if not row:
        return jsonify({'error': 'E-Mail oder Passwort falsch'}), 401

    session['leitstelle_id']   = row['id']
    session['leitstelle_role'] = 'leitstelle'
    user = {'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
            'email': row['email'], 'rolle': row['rolle'], 'role': 'leitstelle'}
    return jsonify({'ok': True, 'user': user,
                    'token': _make_token('leitstelle', str(row['id']))})


@app.route('/api/leitstelle/logout', methods=['POST'])
def leitstelle_logout():
    session.clear()
    return jsonify({'ok': True})


@app.route('/api/leitstelle/me')
def leitstelle_me():
    lid = session.get('leitstelle_id')
    if session.get('admin'):
        return jsonify({'ok': True, 'user': {'id': 'admin', 'vorname': 'Admin', 'nachname': '', 'role': 'admin', 'rolle': 'admin'}})
    if not lid:
        tok = _token_from_request()
        if tok and tok['role'] in ('leitstelle', 'admin'):
            lid = tok['uid']
        else:
            return jsonify({'error': 'Nicht angemeldet'}), 401
    if lid in ('ls_test', ''):
        return jsonify({'ok': True, 'user': TEST_LEITSTELLE})
    with get_db() as db:
        row = db.execute('SELECT * FROM leitstelle_users WHERE id=? AND aktiv=1', [lid]).fetchone()
    if not row:
        return jsonify({'error': 'Sitzung abgelaufen'}), 401
    return jsonify({'ok': True, 'user': {
        'id': row['id'], 'vorname': row['vorname'], 'nachname': row['nachname'],
        'email': row['email'], 'rolle': row['rolle'], 'role': 'leitstelle'
    }})


def require_leitstelle():
    if session.get('admin') or session.get('leitstelle_id'):
        return None
    tok = _token_from_request()
    if tok and tok['role'] in ('leitstelle', 'admin'):
        return None
    return jsonify({'error': 'Kein Zugriff'}), 403


# ── API: Anfragen ───────────────────────────────────────────────────────────

@app.route('/api/requests', methods=['POST'])
def create_request():
    data = request.get_json(silent=True) or {}
    patient_id = data.get('patient_id', '').strip()
    if not patient_id:
        return jsonify({'error': 'patient_id fehlt'}), 400

    # Fetch patient info from DB
    with get_db() as db:
        pat = db.execute('SELECT * FROM patients WHERE id=?', [patient_id]).fetchone()
    if not pat:
        return jsonify({'error': 'Patient nicht gefunden'}), 404

    rid = 'r' + uuid.uuid4().hex[:8]
    pat_name = pat['vorname'] + ' ' + pat['nachname']
    addr_parts = [pat['address'], pat['plz'], pat['ort']]
    pat_addr = ', '.join(p for p in addr_parts if p)
    anamnese = data.get('anamnese', {})
    pflegestufe = anamnese.get('pflegestufe', '') if isinstance(anamnese, dict) else ''
    frequenz = anamnese.get('frequenz', '') if isinstance(anamnese, dict) else ''

    with get_db() as db:
        db.execute(
            'INSERT INTO requests (id,patient_id,patient_name,patient_gender,patient_address,patient_plz,patient_ort,patient_birth,anamnese,pflegestufe,frequenz) '
            'VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [rid, patient_id, pat_name, pat['gender'],
             pat_addr, pat['plz'], pat['ort'], pat['birth'],
             json.dumps(anamnese), pflegestufe, frequenz]
        )
        db.commit()

    return jsonify({'ok': True, 'id': rid})


@app.route('/api/requests/pending')
def list_pending_requests():
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM requests WHERE status='pending' ORDER BY created_at DESC"
        ).fetchall()
    result = []
    for r in rows:
        try:
            anamnese = json.loads(r['anamnese'] or '{}')
        except Exception:
            anamnese = {}
        result.append({
            'id': r['id'],
            'patient_id': r['patient_id'],
            'patient_name': r['patient_name'],
            'patient_gender': r['patient_gender'],
            'patient_address': r['patient_address'],
            'patient_plz': r['patient_plz'],
            'patient_ort': r['patient_ort'],
            'patient_birth': r['patient_birth'],
            'anamnese': anamnese,
            'pflegestufe': r['pflegestufe'],
            'frequenz': r['frequenz'],
            'status': r['status'],
            'created_at': r['created_at'],
        })
    return jsonify({'ok': True, 'requests': result})


@app.route('/api/requests/<rid>/accept', methods=['POST'])
def accept_request(rid):
    caregiver_id = session.get('user_id', '')
    with get_db() as db:
        row = db.execute("SELECT * FROM requests WHERE id=?", [rid]).fetchone()
        if not row:
            return jsonify({'error': 'Anfrage nicht gefunden'}), 404
        db.execute(
            "UPDATE requests SET status='accepted', caregiver_id=? WHERE id=?",
            [caregiver_id, rid]
        )
        db.commit()
    return jsonify({'ok': True})


@app.route('/api/requests/<rid>/decline', methods=['POST'])
def decline_request(rid):
    with get_db() as db:
        row = db.execute("SELECT * FROM requests WHERE id=?", [rid]).fetchone()
        if not row:
            return jsonify({'error': 'Anfrage nicht gefunden'}), 404
        db.execute("UPDATE requests SET status='declined' WHERE id=?", [rid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin Auth ──────────────────────────────────────────────────────────────

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    data = request.get_json(silent=True) or {}
    pw = data.get('password', '')
    if pw == ADMIN_PASSWORD:
        session['admin'] = True
        return jsonify({'ok': True, 'token': _make_token('admin')})
    return jsonify({'error': 'Falsches Passwort'}), 401

@app.route('/api/admin/me')
def admin_me():
    if session.get('admin'):
        return jsonify({'ok': True})
    tok = _token_from_request()
    if tok and tok['role'] == 'admin':
        return jsonify({'ok': True})
    return jsonify({'ok': False}), 401

@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    session.clear()
    return jsonify({'ok': True})

def require_admin():
    if session.get('admin'):
        return None
    tok = _token_from_request()
    if tok and tok['role'] == 'admin':
        return None
    return jsonify({'error': 'Kein Zugriff'}), 403


# ── Admin: Pflegekräfte ──────────────────────────────────────────────────────

@app.route('/api/admin/caregivers')
def admin_caregivers():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute(
            'SELECT c.id, c.vorname, c.nachname, c.email, c.gender, c.ort, c.created_at, '
            'COALESCE(s.status,"active") as status, COALESCE(s.plan,"normal") as plan, COALESCE(s.notes,"") as notes '
            'FROM caregivers c LEFT JOIN caregiver_status s ON c.id=s.caregiver_id '
            'ORDER BY c.created_at DESC'
        ).fetchall()
    return jsonify({'ok': True, 'caregivers': [dict(r) for r in rows]})

@app.route('/api/admin/caregivers/<cid>/status', methods=['POST'])
def admin_set_caregiver_status(cid):
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    status = data.get('status', 'active')
    plan   = data.get('plan', 'normal')
    notes  = data.get('notes', '')
    with get_db() as db:
        db.execute(
            'INSERT INTO caregiver_status (caregiver_id, status, plan, notes, updated_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP) '
            'ON CONFLICT(caregiver_id) DO UPDATE SET status=excluded.status, plan=excluded.plan, notes=excluded.notes, updated_at=excluded.updated_at',
            [cid, status, plan, notes]
        )
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/caregivers/<cid>', methods=['DELETE'])
def admin_delete_caregiver(cid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM caregivers WHERE id=?', [cid])
        db.execute('DELETE FROM caregiver_status WHERE caregiver_id=?', [cid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Dienste / Leitstelle ──────────────────────────────────────────────

@app.route('/api/admin/dienste')
def admin_list_dienste():
    err = require_admin()
    if err: return err
    datum = request.args.get('datum', '')
    with get_db() as db:
        if datum:
            rows = db.execute('SELECT * FROM dienste WHERE datum=? ORDER BY von', [datum]).fetchall()
        else:
            rows = db.execute('SELECT * FROM dienste ORDER BY datum DESC, von', []).fetchall()
    return jsonify({'ok': True, 'dienste': [dict(r) for r in rows]})

@app.route('/api/admin/dienste', methods=['POST'])
def admin_create_dienst():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    required = ['caregiver_id', 'caregiver_name', 'datum', 'von', 'bis']
    for f in required:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld {f} fehlt'}), 400
    did = 'd' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute(
            'INSERT INTO dienste (id, caregiver_id, caregiver_name, datum, von, bis, typ, fahrzeug, notiz) VALUES (?,?,?,?,?,?,?,?,?)',
            [did, data['caregiver_id'], data['caregiver_name'],
             data['datum'], data['von'], data['bis'],
             data.get('typ', 'bereitschaft'), data.get('fahrzeug', ''), data.get('notiz', '')]
        )
        db.commit()
    return jsonify({'ok': True, 'id': did})

@app.route('/api/admin/dienste/<did>', methods=['DELETE'])
def admin_delete_dienst(did):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM dienste WHERE id=?', [did])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Leitstelle-Benutzer ───────────────────────────────────────────────

@app.route('/api/admin/leitstelle-users')
def admin_list_leitstelle_users():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT id,vorname,nachname,email,rolle,aktiv,created_at FROM leitstelle_users ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'users': [dict(r) for r in rows]})

@app.route('/api/admin/leitstelle-users', methods=['POST'])
def admin_create_leitstelle_user():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname', 'email', 'password']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    uid = 'ls_' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO leitstelle_users (id,vorname,nachname,email,password_hash,rolle,aktiv) VALUES (?,?,?,?,?,?,1)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('rolle', 'disponent')]
            )
            db.commit()
    except Exception as ex:
        return jsonify({'error': str(ex)}), 409
    return jsonify({'ok': True, 'id': uid})

@app.route('/api/admin/leitstelle-users/<uid>', methods=['DELETE'])
def admin_delete_leitstelle_user(uid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM leitstelle_users WHERE id=?', [uid])
        db.commit()
    return jsonify({'ok': True})

@app.route('/api/admin/leitstelle-users/<uid>/password', methods=['POST'])
def admin_reset_leitstelle_pw(uid):
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    pw = data.get('password', '').strip()
    if len(pw) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    with get_db() as db:
        db.execute('UPDATE leitstelle_users SET password_hash=? WHERE id=?', [hash_pw(pw), uid])
        db.commit()
    return jsonify({'ok': True})


# ── Admin: Pfleger-Konten (Kurzerfassung) ────────────────────────────────────

@app.route('/api/admin/pfleger', methods=['POST'])
def admin_create_pfleger():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    for f in ['vorname', 'nachname', 'email', 'password']:
        if not data.get(f, '').strip():
            return jsonify({'error': f'Feld "{f}" fehlt'}), 400
    if len(data['password']) < 8:
        return jsonify({'error': 'Passwort mind. 8 Zeichen'}), 400
    uid = 'c' + uuid.uuid4().hex[:8]
    try:
        with get_db() as db:
            db.execute(
                'INSERT INTO caregivers (id,vorname,nachname,email,password_hash,gender,address,plz,ort,bezirk) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [uid, data['vorname'].strip(), data['nachname'].strip(),
                 data['email'].strip().lower(), hash_pw(data['password']),
                 data.get('gender',''), data.get('address',''),
                 data.get('plz',''), data.get('ort',''), data.get('bezirk','')]
            )
            db.commit()
    except Exception as ex:
        return jsonify({'error': str(ex)}), 409
    return jsonify({'ok': True, 'id': uid})


# ── Admin: Nachrichten ───────────────────────────────────────────────────────

@app.route('/api/admin/messages')
def admin_list_messages():
    err = require_admin()
    if err: return err
    with get_db() as db:
        rows = db.execute('SELECT * FROM admin_messages ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'messages': [dict(r) for r in rows]})

@app.route('/api/admin/messages', methods=['POST'])
def admin_create_message():
    err = require_admin()
    if err: return err
    data = request.get_json(silent=True) or {}
    text = data.get('text', '').strip()
    if not text:
        return jsonify({'error': 'Text fehlt'}), 400
    mid = 'm' + uuid.uuid4().hex[:8]
    with get_db() as db:
        db.execute(
            'INSERT INTO admin_messages (id, text, typ, aktiv) VALUES (?,?,?,1)',
            [mid, text, data.get('typ', 'info')]
        )
        db.commit()
    return jsonify({'ok': True, 'id': mid})

@app.route('/api/admin/messages/<mid>', methods=['DELETE'])
def admin_delete_message(mid):
    err = require_admin()
    if err: return err
    with get_db() as db:
        db.execute('DELETE FROM admin_messages WHERE id=?', [mid])
        db.commit()
    return jsonify({'ok': True})

# Public: aktive Meldungen fürs Dashboard
@app.route('/api/messages/active')
def public_active_messages():
    with get_db() as db:
        rows = db.execute('SELECT id, text, typ FROM admin_messages WHERE aktiv=1 ORDER BY created_at DESC').fetchall()
    return jsonify({'ok': True, 'messages': [dict(r) for r in rows]})


# ── Admin: Stats ─────────────────────────────────────────────────────────────

@app.route('/api/admin/stats')
def admin_stats():
    err = require_admin()
    if err: return err
    with get_db() as db:
        cg_total  = db.execute('SELECT COUNT(*) FROM caregivers').fetchone()[0]
        cg_active = db.execute("SELECT COUNT(*) FROM caregivers c LEFT JOIN caregiver_status s ON c.id=s.caregiver_id WHERE COALESCE(s.status,'active')='active'").fetchone()[0]
        cg_locked = db.execute("SELECT COUNT(*) FROM caregiver_status WHERE status='locked'").fetchone()[0]
        pat_total = db.execute('SELECT COUNT(*) FROM patients').fetchone()[0]
        req_pend  = db.execute("SELECT COUNT(*) FROM requests WHERE status='pending'").fetchone()[0]
        dienste_today = db.execute("SELECT COUNT(*) FROM dienste WHERE datum=date('now')").fetchone()[0]
    return jsonify({'ok': True, 'stats': {
        'cg_total': cg_total, 'cg_active': cg_active, 'cg_locked': cg_locked,
        'pat_total': pat_total, 'req_pending': req_pend, 'dienste_today': dienste_today
    }})


# ── Einsätze API ─────────────────────────────────────────────────────────────

@app.route('/api/einsaetze', methods=['GET'])
def list_einsaetze():
    with get_db() as db:
        rows = db.execute("SELECT * FROM einsaetze ORDER BY created_at DESC LIMIT 100").fetchall()
    result = []
    for row in rows:
        e = row_to_dict(row)
        e['risiken'] = json.loads(e.get('risiken') or '[]')
        e['extra']   = json.loads(e.get('extra')   or '{}')
        result.append(e)
    return jsonify(result)

@app.route('/api/einsaetze', methods=['POST'])
def create_einsatz():
    data = request.get_json(silent=True) or {}
    eid  = data.get('id') or ('e_' + str(uuid.uuid4())[:8])
    with get_db() as db:
        db.execute(
            '''INSERT OR REPLACE INTO einsaetze
               (id,nummer,art,dringlichkeit,patient_name,patient_adresse,patient_plz,patient_ort,
                patient_geburt,patient_sv,patient_tel,bezirk,schluessel,adressinfo,
                problem,risiken,allergien,medikamente,anordnungen,qualifikation,
                fahrzeug,disponent,datum,zeit,ang_name,ang_tel,notiz,extra,status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (eid,
             data.get('nummer',''),   data.get('art',''),        data.get('dringlichkeit',''),
             data.get('patient_name',''), data.get('patient_adresse',''),
             data.get('patient_plz',''),  data.get('patient_ort',''),
             data.get('patient_geburt',''), data.get('patient_sv',''), data.get('patient_tel',''),
             data.get('bezirk',''),    data.get('schluessel',''), data.get('adressinfo',''),
             data.get('problem',''),   json.dumps(data.get('risiken',[])),
             data.get('allergien',''), data.get('medikamente',''), data.get('anordnungen',''),
             data.get('qualifikation',''), data.get('fahrzeug',''), data.get('disponent',''),
             data.get('datum',''),     data.get('zeit',''),
             data.get('ang_name',''),  data.get('ang_tel',''),
             data.get('notiz',''),     json.dumps(data.get('extra',{})),
             data.get('status','alarmiert')))
    return jsonify({'id': eid, 'ok': True})

@app.route('/api/einsaetze/aktuell')
def get_aktuell_einsatz():
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM einsaetze WHERE status NOT IN ('beendet','storniert') ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
    if not row:
        return jsonify(None)
    e = row_to_dict(row)
    e['risiken'] = json.loads(e.get('risiken') or '[]')
    e['extra']   = json.loads(e.get('extra')   or '{}')
    return jsonify(e)

@app.route('/api/einsaetze/<eid>')
def get_einsatz(eid):
    with get_db() as db:
        row = db.execute("SELECT * FROM einsaetze WHERE id=?", (eid,)).fetchone()
    if not row:
        return jsonify({'error': 'not found'}), 404
    e = row_to_dict(row)
    e['risiken'] = json.loads(e.get('risiken') or '[]')
    e['extra']   = json.loads(e.get('extra')   or '{}')
    return jsonify(e)

@app.route('/api/einsaetze/<eid>/status', methods=['POST'])
def update_einsatz_status(eid):
    data   = request.get_json(silent=True) or {}
    status = data.get('status','')
    if status not in ('alarmiert','unterwegs','eingetroffen','beendet','einsatzbereit'):
        return jsonify({'error': 'invalid status'}), 400
    with get_db() as db:
        db.execute("UPDATE einsaetze SET status=? WHERE id=?", (status, eid))
    return jsonify({'ok': True, 'status': status})

@app.route('/api/einsaetze/<eid>/nachrichten', methods=['GET'])
def get_einsatz_nachrichten(eid):
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM einsatz_nachrichten WHERE einsatz_id=? ORDER BY created_at ASC", (eid,)
        ).fetchall()
    return jsonify([row_to_dict(r) for r in rows])

@app.route('/api/einsaetze/<eid>/nachrichten', methods=['POST'])
def send_einsatz_nachricht(eid):
    data   = request.get_json(silent=True) or {}
    text   = data.get('text','').strip()
    if not text:
        return jsonify({'error': 'empty'}), 400
    sender = data.get('sender','pfleger')
    mid    = 'msg_' + str(uuid.uuid4())[:8]
    with get_db() as db:
        db.execute(
            "INSERT INTO einsatz_nachrichten (id,einsatz_id,sender,text) VALUES (?,?,?,?)",
            (mid, eid, sender, text)
        )
    return jsonify({'ok': True, 'id': mid})


# ── Static files ────────────────────────────────────────────────────────────

@app.route('/')
def index():
    resp = send_from_directory(BASE_DIR, 'index.html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp

@app.route('/<path:filename>')
def static_files(filename):
    resp = send_from_directory(BASE_DIR, filename)
    if filename.endswith('.html'):
        resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        resp.headers['Pragma'] = 'no-cache'
        resp.headers['Expires'] = '0'
    return resp


# ── Entry point ─────────────────────────────────────────────────────────────

if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5000))
    print(f'Nursy API + static server on port {port}', flush=True)
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
